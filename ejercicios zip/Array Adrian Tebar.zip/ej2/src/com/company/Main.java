package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // write your code here
        int[] n = new int[10];
        int i;
        Scanner sc = new Scanner(System.in);
        System.out.println("Por favor, introduzca 10 números enteros.");
        System.out.println("Pulse la tecla INTRO después de introducir cada número.");
        n[0] = sc.nextInt();
        n[1] = sc.nextInt();
        n[2] = sc.nextInt();
        n[3] = sc.nextInt();
        n[4] = sc.nextInt();
        n[5] = sc.nextInt();
        n[6] = sc.nextInt();
        n[7] = sc.nextInt();
        n[8] = sc.nextInt();
        n[9] = sc.nextInt();

        System.out.println("\nLos números introducidos, al revés, son los siguientes:");
        for (i = 9; i >= 0; i--) {
            System.out.println(n[i]);

        }
    }
}



