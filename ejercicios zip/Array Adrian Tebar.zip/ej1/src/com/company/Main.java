package com.company;

import com.sun.javafx.scene.layout.region.Margins;

import java.io.Console;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // Escribe un programa que pida al usuario 4 números, los memorice (utilizando un
        //array), calcule su media aritmética y después muestre en pantalla la media y los
        //datos tecleados.
        Scanner sc = new Scanner(System.in);
        int[] numero = new int[4];
        int suma = 0;
        double resul=0;
        System.out.println("incresa 4 numeros");
        numero[0]=sc.nextInt();
        numero[1]=sc.nextInt();
        numero[2]=sc.nextInt();
        numero[3]=sc.nextInt();
        for (int i = 0; i < numero.length; i++) {
            suma=numero[0]+numero[1]+numero[2]+numero[3];
            resul=suma/4;

        }
        System.out.println("estos son los 4  numeros " + numero[0] +" "+ + numero[1] +" "+ numero[2] +" "+ numero[3]);
        System.out.println("este es el resultado " + resul);


    }
}

