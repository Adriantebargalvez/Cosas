package com.company;

public class Persona {
    private String DNI;
    private String NOMBRE;
    private String apellido;
    private int edad;
    //constructores
    public Persona(String DNI, String NOMBRE, String apellido, int edad) {
        this.DNI = DNI;
        this.NOMBRE = NOMBRE;
        this.apellido = apellido;
        this.edad = edad;
    }

    public Persona() {
    }

    //setter
    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public void setNOMBRE(String NOMBRE) {
        this.NOMBRE = NOMBRE;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getNOMBRE() {
        return NOMBRE;
    }

    //Metodos
    public void setAll(String dni,String nombre,String apellido,int edad){
        this.DNI = DNI;
        this.NOMBRE = NOMBRE;
        this.apellido = apellido;
        this.edad = edad;
    }
    public void imprime(){
        System.out.println(NOMBRE+" "+apellido+"con dni "+DNI+"edad es "+edad);
    }
    public boolean esMayorEdad(){
        if (edad>=10)
            return true;
        else
            return false;
    }
    public boolean EsJubilado(){
        return edad>=65;

    }
    public int diferenciaDeEdad(Persona p){
        int diferencia=this.edad-p.edad;
        return diferencia;
    }
}


