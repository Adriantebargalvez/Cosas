package com.company;
import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner sc =new Scanner(System.in);
Persona p1= new Persona("12345678N","pepe","grillo",10);
Persona p2=new Persona("87654321","juan","david",20);


Persona p3=new Persona();
Persona p4 =new Persona();

        System.out.println("Introducce el DNI");
        String dni= sc.next();
        System.out.println("Introducce el Nombre");
        String Nombre= sc.next();
        System.out.println("Introducce el Apellido");
        String apellido= sc.next();

        System.out.println("Introducce el Edad");
       int edad= sc.nextInt();
        p4.setAll(dni,Nombre,apellido,edad);
        p1.imprime();
        p2.imprime();
        p3.imprime();
        p4.imprime();
        if (p3.esMayorEdad())
            System.out.println(p3.getNOMBRE()+"Es mayor de edad");
        if (p4.EsJubilado())
            System.out.println("es jubilado");
        else
            System.out.println("no esta jubilado");

        System.out.println("La diferencia es"+p1.diferenciaDeEdad(p2));

    }
}
