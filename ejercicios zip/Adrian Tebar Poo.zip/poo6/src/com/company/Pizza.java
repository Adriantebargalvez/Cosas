package com.company;

public class Pizza {
    private String tamaño;
    private String tipo;
    private String estado;

    //constructor
    public Pizza(String tamaño, String tipo) {
        this.tamaño = tamaño;
        this.tipo = tipo;
        this.estado="pedida";
    }

    public Pizza() {
    }
    //getter y setter

    public String getTamaño() {
        return tamaño;
    }

    public void setTamaño(String tamaño) {
        this.tamaño = tamaño;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void imprimir() {
        System.out.println(tamaño + "es " + tipo + "esta " + estado);
    }
    public void sirve(){
        System.out.println("Ya estan servidas");
    }
}