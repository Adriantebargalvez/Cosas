package com.company;

public class Main {

    public static void main(String[] args) {
        Pizza p1 = new Pizza("mediana","margarita");
        Pizza p2 = new Pizza("funghi", "familiar");
        p2.sirve();
        Pizza p3 = new Pizza("cuatro quesos", "mediana");
        p1.imprimir();
        p2.imprimir();
        p3.imprimir();
        p2.sirve();

    }
}
