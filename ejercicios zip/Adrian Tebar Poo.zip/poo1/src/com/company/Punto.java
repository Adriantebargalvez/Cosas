package com.company;

public class Punto {
    private int x;
    private int y;

// Constructor

    public Punto() {
    }

    public Punto(int x, int y) {
        this.x = x;
        this.y = y;
    }
// geters y seters
    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
    //metodo
    public void imprimir(){
        System.out.println("la x es "+x+"la y es "+y);

    }
    public void setXY(int x,int y){
        this.x +=x;
        this.y +=y;
    }
    public void desplazamiento(int dx, int dy){
        this.x +=dx;
        this.y +=dy;
    }
    public int distancia(Punto p){
        double aux =Math.sqrt(Math.pow(this.x-p.x,2)+Math.pow(this.y-p.y,2));
        return (int) aux;
    }
}
