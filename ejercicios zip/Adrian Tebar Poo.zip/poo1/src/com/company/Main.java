package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
 Punto p1=new Punto();
Punto p2=new Punto(-3,7);
Punto p3=new Punto(10,10);
p1.setX(5);
p1.setY(0);
        System.out.println("la x es "+p1.getX()+"y la y "+p1.getX());
        System.out.println("la x es "+p2.getX()+"y la y "+p2.getY());
        p1.setXY(2,5);
        p1.imprimir();
        p1.desplazamiento(1,2);
        p2.imprimir();
        int aux=p1.distancia(p2);
        System.out.println("la distancia es "+aux);

    }
}
