package com.company;

import java.util.Scanner;

public class Main {
static Scanner sc=new Scanner(System.in);
    public static void main(String[] args) {
       Zona normal =new Zona(1000);
        Zona vip = new Zona(25);
        Zona compra_venta = new Zona(200);
        int opcion;
        do {
            System.out.println("1. Mostrar número de entradas libres\n" +
                    "2. Vender entradas\n" +
                    "3. Salir ");
            opcion =sc.nextInt();
            switch (opcion){
                case 1:
                    System.out.println("entradas libres "+normal.getEntradasPorVender()+" Vips "+ vip.getEntradasPorVender());
                    break;
                case 2:
                    System.out.println("Cuantas entradas quieres");
                   int entrada=sc.nextInt();
                    System.out.println("Para que zona quieres(normal,cotra_venta o vip");
                    String zonas=sc.next();
                    if (entrada<normal.getEntradasPorVender() && zonas.equals("normal"))
                        normal.vender(entrada);
                 else if (entrada< vip.getEntradasPorVender() && zonas.equals("vip"))
                        vip.vender(entrada);
                    else if (entrada< compra_venta.getEntradasPorVender() && zonas.equals("compra_venta"))
                        vip.vender(entrada);
                    else
                        System.out.println("No se a podido realizar");

                    break;
                case 3:
                    System.out.println("Has salido");
                    break;
                default:
                    System.out.println("No es niguna opcion");
            }
        }while (opcion!=3);
    }
    }

