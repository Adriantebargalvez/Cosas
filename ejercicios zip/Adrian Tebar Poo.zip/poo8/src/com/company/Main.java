package com.company;

import java.util.Scanner;

public class Main {
static Scanner sc =new Scanner(System.in);
    public static void main(String[] args) {
        CuentaBancaria c1=new CuentaBancaria("E2233343434","Adrian");
        int opcion;
        do {
            System.out.println("1. Datos de la cuenta. Mostrará el IBAN, el titular y el saldo\n" +
                    "            2 IBAN Mostrará el IBAN\n" +
                    "            3. Titular. Mostrará el titular.\n" +
                    "            4. Saldo. Mostrará el saldo disponible.\n" +
                    "            5. Ingreso. Pedirá la cantidad a ingresar y realizará el ingreso si es posible.\n" +
                    "            6. Retirada. Pedirá la cantidad a retirar y realizará la retirada si es posible.\n" +
                    "            7. Salir. Termina el programa.");
            opcion =sc.nextInt();
            switch (opcion){
                case 1:
                   c1.imprimir();
                    break;
                case 2:
                    System.out.println("Iban"+c1.getIban());
                    break;
                case 3:
                    System.out.println("titular"+c1.getNombre());
                    break;
                case 4:
                    System.out.println("Saldo"+c1.getSaldo());
                    break;
                case 5:
                    System.out.println("cantidad ingresar");
                    double c= sc.nextDouble();
                    c1.ingreso(c);
                    break;
                case 6:
                    System.out.println("cantidad retirada");
                    c= sc.nextDouble();
                    c1.retirada(c);
                    break;
                case 7:
                    System.out.println("Has salido");
                    break;
                default:
                    System.out.println("No es niguna opcion");
            }
        }while (opcion!=7);
    }
}
