package com.company;

public class CuentaBancaria {
    private String iban;
    private String nombre;
    private int saldo = 0;

    //constructor
    public CuentaBancaria() {
    }

    public CuentaBancaria(String iban, String nombre) {
        this.iban = iban;
        this.nombre = nombre;
    }

    //getter y setter
    public String getIban() {
        return iban;
    }

    public void setIban(String iban) {
        this.iban = iban;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    //Metodos
    public void imprimir() {
        System.out.println("El iban de la cuenta es:" + iban);
        System.out.println("El iban de la cuenta es:" + nombre);
    }
        public void ingreso ( double cantidad){
            if (cantidad < 0)
                System.out.println("No se puede ingresar");
            saldo += cantidad;
        }
        public void retirada ( double cantidad){
            if (cantidad < 0)
                System.out.println("No se puede retirar");
            if (cantidad >= 3000)
                System.out.println("Aviso:notificar hacienda");
            if (saldo - cantidad >= -50)
                saldo -= cantidad;
            if (saldo-cantidad<-50)
                System.out.println("No hay saldo");
            if (saldo - cantidad < 0 && saldo - cantidad >= -50)
                System.out.println("Aviso: saldo negativo");
        }
    }




