package com.company;

public class eje2 {
    public static void main(String[] args) {
        String numTelefono = "5256284000";
        String Cadena = "("+numTelefono.substring(0,2)+")-"+numTelefono.charAt(2)+"-"+numTelefono.substring(3);

        System.out.println(Cadena);
    }
}
