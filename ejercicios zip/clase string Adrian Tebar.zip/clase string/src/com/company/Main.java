package com.company;

public class Main {

    public static void main(String[] args) {

        String cadena = "Hola Lourdes";
        int contador = 0;
        for (int i = 0; i < cadena.length(); i++) {
            if (cadena.charAt(i) == ' ') {
                contador++;
            }
        }
        System.out.println("La cadena contiene " + (contador + 1) + " palabras");
    }
}
