package com.company;

import jdk.nashorn.internal.objects.NativeString;

import java.util.ArrayList;
import java.util.Scanner;

public class eje3 {

   static public String mensaje() {
       String mensaje="hola";
        String resultado = "";
        for (int i = 0; i < mensaje.length(); i++) {
            char caracterActual = mensaje.charAt(i);
            if (caracterActual == 'Z') {
                resultado += 'A';
            } else {
                char caracterSiguiente = (char) (caracterActual + 1);
                resultado += caracterSiguiente;
            }
        }
        return resultado;
    }

    static public String mayuscula(){
        String mensaje = "Este es un mensaje secreto";
        String mensajeCodificado = mensaje.toUpperCase();
        return (mensajeCodificado);

    }
    static public String num(){
        String message="34-345-39";

        String encryptedMessage = "";


        for(int i = 0; i < message.length(); i++){
            char c = message.charAt(i);
            if(Character.isDigit(c)){
                if(c == '9'){
                    encryptedMessage += '0';
                }
                else{
                    encryptedMessage += (c + 1);
                }
            }
            else{
                encryptedMessage += c;
            }
        }
        return encryptedMessage;
    }
    public static void main(String[] args) {

        String alfa= "abcdefghijklmnñopqrstuvwxyz0123456789";
        String alfa2= "bcdefghijklmnñopqrstuvwxyza1234567890";
        ArrayList<String> alfabeto = new ArrayList<>();
        ArrayList<String> alfabeto2 = new ArrayList<>();
        for (int i = 0; i <alfa.length() ; i++) {

        }
        System.out.println(mayuscula());
        System.out.println(mensaje());
        System.out.println(num());


    }


}
