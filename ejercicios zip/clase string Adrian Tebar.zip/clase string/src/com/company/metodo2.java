package com.company;

public class metodo2 {
    public static void main(String[] args) {
    String cadena = "Hola a todo el mundo";
    String[] palabras = cadena.split(" ");
    System.out.println("La cadena contiene " + palabras.length + " palabras");



}
}

