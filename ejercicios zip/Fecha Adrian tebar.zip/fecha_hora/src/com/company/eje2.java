package com.company;

import java.util.Calendar;
import java.util.Scanner;

public class eje2 {
    //Haz un programa que calcule el día de incorporación después de una baja de
   // maternidad/paternidad(16 semanas). El usuario introducirá la fecha de
    //nacimiento del bebe y el programa le dirá que día se tiene que incorporar.


    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Por favor, introduce la fecha de nacimiento de tu bebé (dd/mm/aaaa):");
        String input = scanner.nextLine();
        String[] fechaNacimiento = input.split("/");
        int dia = Integer.parseInt(fechaNacimiento[0]);
        int mes = Integer.parseInt(fechaNacimiento[1]);
        int anio = Integer.parseInt(fechaNacimiento[2]);

        Calendar fechaIncorporacion = Calendar.getInstance();
        fechaIncorporacion.set(anio, mes-1, dia);
        fechaIncorporacion.add(Calendar.WEEK_OF_YEAR, 16);

        int diaIncorporacion = fechaIncorporacion.get(Calendar.DAY_OF_MONTH);
        int mesIncorporacion = fechaIncorporacion.get(Calendar.MONTH) + 1;
        int anioIncorporacion = fechaIncorporacion.get(Calendar.YEAR);

        System.out.println("Tu día de incorporación es el " + diaIncorporacion + "/" + mesIncorporacion + "/" + anioIncorporacion);
    }
}





