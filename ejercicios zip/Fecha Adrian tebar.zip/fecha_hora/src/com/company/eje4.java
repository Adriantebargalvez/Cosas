package com.company;

import java.util.Scanner;

public class eje4 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("¡Bienvenido! Por favor selecciona una estación del año (primavera, verano, otoño e invierno): ");
        String seleccion = scanner.nextLine();

        //Calcular los días restantes para la estación elegida
        int diasRestantes;
        switch (seleccion) {
            case "primavera":
                diasRestantes = calculaDiasHastaPrimavera(calculaDiasMesActual());
                break;
            case "verano":
                diasRestantes = calculaDiasHastaVerano(calculaDiasMesActual());
                break;
            case "otoño":
                diasRestantes = calculaDiasHastaOtoño(calculaDiasMesActual());
                break;
            case "invierno":
                diasRestantes = calculaDiasHastaInvierno(calculaDiasMesActual());
                break;
            default:
                System.out.println("Estación no válida.");
                return;
        }

        //Mostrar los días restantes
        if (diasRestantes > 0) {
            System.out.println("Quedan " + diasRestantes + " días para que empiece la estación de " + seleccion + ".");
        } else {
            System.out.println("¡Ya estamos en la estación de " + seleccion + "!");
        }

    }

    //Calcular el número de días desde el 1 de enero hasta el mes actual
    private static int calculaDiasMesActual() {
        int diasMesActual = 0;
        int mesActual = java.time.LocalDate.now().getMonthValue();

        switch (mesActual) {
            case 1:
                diasMesActual = 0;
                break;
            case 2:
                diasMesActual = 31;
                break;
            case 3:
                diasMesActual = 59;
                break;
            case 4:
                diasMesActual = 90;
                break;
            case 5:
                diasMesActual = 120;
                break;
            case 6:
                diasMesActual = 151;
                break;
            case 7:
                diasMesActual = 181;
                break;
            case 8:
                diasMesActual = 212;
                break;
            case 9:
                diasMesActual = 243;
                break;
            case 10:
                diasMesActual = 273;
                break;
            case 11:
                diasMesActual = 304;
                break;
            case 12:
                diasMesActual = 334;
                break;
            default:
                System.out.println("Mes no válido.");
        }
        return diasMesActual;
    }

    //Calcular el número de días desde el 1 de enero hasta el comienzo de la primavera
    private static int calculaDiasHastaPrimavera(int diasMesActual) {
        int diasRestantes;
        if (diasMesActual <= 90) {
            diasRestantes = 91 - diasMesActual;
        } else {
            diasRestantes = 365 - diasMesActual + 91;
        }
        return diasRestantes;
    }

    //Calcular el número de días desde el 1 de enero hasta el comienzo del verano
    private static int calculaDiasHastaVerano(int diasMesActual) {
        int diasRestantes;
        if (diasMesActual <= 151) {
            diasRestantes = 152 - diasMesActual;
        } else {
            diasRestantes = 365 - diasMesActual + 152;
        }
        return diasRestantes;
    }

    //Calcular el número de días desde el 1 de enero hasta el comienzo del otoño
    private static int calculaDiasHastaOtoño(int diasMesActual) {
        int diasRestantes;
        if (diasMesActual <= 212) {
            diasRestantes = 213 - diasMesActual;
        } else {
            diasRestantes = 365 - diasMesActual + 213;
        }
        return diasRestantes;
    }

    //Calcular el número de días desde el 1 de enero hasta el comienzo del invierno
    private static int calculaDiasHastaInvierno(int diasMesActual) {
        int diasRestantes;
        if (diasMesActual <= 273) {
            diasRestantes = 274 - diasMesActual;
        } else {
            diasRestantes = 365 - diasMesActual + 274;
        }
        return diasRestantes;
    }

}