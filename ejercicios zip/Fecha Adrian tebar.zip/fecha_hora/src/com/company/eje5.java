package com.company;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


public class eje5 {

    public static void main(String[] args) {

        LocalDate fechaActual=LocalDate.now();
        LocalDate fechaFinal=fechaActual.plusYears(1);
        List<LocalDate> listaFechas = new ArrayList<>();

        while (fechaActual.isBefore(fechaFinal)){
            if (fechaActual.getDayOfMonth()==1&&fechaActual.getDayOfWeek().getValue()==1){
                listaFechas.add(fechaActual);
            }
            fechaActual=fechaActual.plusDays(1);
        }

        for(LocalDate fecha:listaFechas){
            System.out.println(fecha.getDayOfMonth()+"-"+fecha.getMonthValue()+"-"+fecha.getYear());
        }
    }
}