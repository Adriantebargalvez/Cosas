package com.company;
import java.util.Calendar;
import java.util.Date;
public class Eje3 {
    /*Hacer un programa que tenga un método que reciba dos parámetros, uno con la
    fecha a modificar, y el segundo con la cantidad de días a sumar o restar. Si la
    cantidad de días es mayor que cero entonces se sumarán dichos días a la fecha,
    por el contrario, si la variable días es menor que cero, entonces se restarán dichos
    días a la fecha. Comprobar que el método funciona.*/

        public static void main(String[] args) {
            Date fechaActual = new Date();

            //sumamos 5 dias a la fecha actual
            Date nuevaFecha = sumarFecha(fechaActual, 5);
            System.out.println("Fecha actual mas 5 dias: " + nuevaFecha);

            //restamos 15 dias a la fecha actual
            nuevaFecha = sumarFecha(fechaActual, -15);
            System.out.println("Fecha actual menos 15 dias: " + nuevaFecha);
        }

        public static Date sumarFecha(Date fecha, int dias){

            Calendar calendar = Calendar.getInstance();
            calendar.setTime(fecha);

            calendar.add(Calendar.DAY_OF_YEAR, dias);

            return calendar.getTime();
        }
    }



