package com.company;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.Scanner;
public class Main {


    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Por favor, ingresa tu fecha de nacimiento (en formato DD/MM/AAAA):");

        String fechaString = scanner.nextLine();
        String[] partesFecha = fechaString.split("/");
        int dia = Integer.parseInt(partesFecha[0]);
        int mes = Integer.parseInt(partesFecha[1]);
        int anio = Integer.parseInt(partesFecha[2]);

        LocalDate fechaNacimiento = LocalDate.of(anio, mes, dia);
        DayOfWeek diaDeLaSemana = fechaNacimiento.getDayOfWeek();
        System.out.println("Tu fecha de nacimiento fue un " + diaDeLaSemana.toString() + "!");
    }
}
