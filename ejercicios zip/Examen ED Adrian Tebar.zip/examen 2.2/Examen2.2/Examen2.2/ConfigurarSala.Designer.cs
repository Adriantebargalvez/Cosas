﻿namespace Examen2._2
{
    partial class ConfigurarSala
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Sala = new System.Windows.Forms.Label();
            this.opciones = new System.Windows.Forms.Label();
            this.Pelicula1 = new System.Windows.Forms.Label();
            this.aforo = new System.Windows.Forms.Label();
            this.ocupadas = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.Entradas = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.Terminado = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            this.SuspendLayout();
            // 
            // Sala
            // 
            this.Sala.AutoSize = true;
            this.Sala.Location = new System.Drawing.Point(29, 38);
            this.Sala.Name = "Sala";
            this.Sala.Size = new System.Drawing.Size(44, 25);
            this.Sala.TabIndex = 0;
            this.Sala.Text = "Sala";
            // 
            // opciones
            // 
            this.opciones.AutoSize = true;
            this.opciones.Location = new System.Drawing.Point(12, 160);
            this.opciones.Name = "opciones";
            this.opciones.Size = new System.Drawing.Size(84, 25);
            this.opciones.TabIndex = 1;
            this.opciones.Text = "opciones";
            // 
            // Pelicula1
            // 
            this.Pelicula1.AutoSize = true;
            this.Pelicula1.Location = new System.Drawing.Point(93, 237);
            this.Pelicula1.Name = "Pelicula1";
            this.Pelicula1.Size = new System.Drawing.Size(69, 25);
            this.Pelicula1.TabIndex = 2;
            this.Pelicula1.Text = "Pelicula";
            // 
            // aforo
            // 
            this.aforo.AutoSize = true;
            this.aforo.Location = new System.Drawing.Point(93, 303);
            this.aforo.Name = "aforo";
            this.aforo.Size = new System.Drawing.Size(55, 25);
            this.aforo.TabIndex = 3;
            this.aforo.Text = "aforo";
            // 
            // ocupadas
            // 
            this.ocupadas.AutoSize = true;
            this.ocupadas.Location = new System.Drawing.Point(93, 366);
            this.ocupadas.Name = "ocupadas";
            this.ocupadas.Size = new System.Drawing.Size(89, 25);
            this.ocupadas.TabIndex = 4;
            this.ocupadas.Text = "ocupadas";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(219, 244);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(262, 23);
            this.textBox1.TabIndex = 5;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(200, 301);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(48, 31);
            this.numericUpDown1.TabIndex = 6;
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(200, 364);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(48, 31);
            this.numericUpDown2.TabIndex = 7;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Sala1",
            "Sala2",
            "Sala3",
            "Sala4"});
            this.comboBox1.Location = new System.Drawing.Point(155, 41);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(386, 33);
            this.comboBox1.TabIndex = 8;
            // 
            // Entradas
            // 
            this.Entradas.AutoSize = true;
            this.Entradas.Location = new System.Drawing.Point(517, 247);
            this.Entradas.Name = "Entradas";
            this.Entradas.Size = new System.Drawing.Size(80, 25);
            this.Entradas.TabIndex = 9;
            this.Entradas.Text = "Entradas";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(620, 257);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(121, 29);
            this.checkBox1.TabIndex = 10;
            this.checkBox1.Text = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(620, 303);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(121, 29);
            this.checkBox2.TabIndex = 11;
            this.checkBox2.Text = "checkBox2";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(620, 362);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(121, 29);
            this.checkBox3.TabIndex = 12;
            this.checkBox3.Text = "checkBox3";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // Terminado
            // 
            this.Terminado.Location = new System.Drawing.Point(311, 358);
            this.Terminado.Name = "Terminado";
            this.Terminado.Size = new System.Drawing.Size(226, 29);
            this.Terminado.TabIndex = 13;
            this.Terminado.Text = "Terminado";
            this.Terminado.UseVisualStyleBackColor = true;
            this.Terminado.Click += new System.EventHandler(this.Terminado_Click);
            // 
            // ConfigurarSala
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Terminado);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.Entradas);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.numericUpDown2);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.ocupadas);
            this.Controls.Add(this.aforo);
            this.Controls.Add(this.Pelicula1);
            this.Controls.Add(this.opciones);
            this.Controls.Add(this.Sala);
            this.Name = "ConfigurarSala";
            this.Text = "ConfigurarSala";
            this.Load += new System.EventHandler(this.ConfigurarSala_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label Sala;
        private Label opciones;
        private Label Pelicula1;
        private Label aforo;
        private Label ocupadas;
        private TextBox textBox1;
        private NumericUpDown numericUpDown1;
        private NumericUpDown numericUpDown2;
        private ComboBox comboBox1;
        private Label Entradas;
        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private CheckBox checkBox3;
        private Button Terminado;
    }
}