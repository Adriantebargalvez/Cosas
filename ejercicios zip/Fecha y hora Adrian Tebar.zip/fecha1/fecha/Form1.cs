﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fecha
{
    public partial class Form1 : Form
    {
        int suma;
       

        public Form1()
        {
            InitializeComponent();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
           suma = 2022- dateTimePicker1.Value.Year;
            label1.Text=suma.ToString();
    
        }

    }
}
