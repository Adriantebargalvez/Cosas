﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace fecha3
{
    public partial class Form1 : Form
    {
        int seg = 9;
        int suma,resta,multi,divi;

        private void label2_Click(object sender, EventArgs e)
        {

        }

        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            seg--;
            label8.Text = seg.ToString();
            if (seg == 0)
            {
                timer1.Stop();
                button1.Enabled = true;
                if (suma == numericUpDown1.Value && resta == numericUpDown2.Value && multi == numericUpDown3.Value && divi==numericUpDown4.Value)
                {
                    MessageBox.Show("has acertado todas");
                }
                if (suma != numericUpDown1.Value || resta != numericUpDown2.Value || multi != numericUpDown3.Value || divi == numericUpDown4.Value)
                {
                    MessageBox.Show("has perdido");
                }
            }
           
        }
        private void button1_Click(object sender, EventArgs e)
        {
            seg = 20;


            var random = new Random();int month = random.Next(1, 9); var random2 = new Random();
            int month2 = random.Next(1, 9); var random3 = new Random(); int month3 = random.Next(1, 9); var random4 = new Random();
            int month4 = random.Next(1, 9); var random5 = new Random(); int month5 = random.Next(1, 9); var random6 = new Random();
            int month6 = random.Next(1, 9); var random7 = new Random(); int month7 = random.Next(1, 9); var random8 = new Random(); int month8 = random.Next(1, 9);

            label1.Text = month.ToString();
                label2.Text = month2.ToString();
                label3.Text = month3.ToString();
                label4.Text = month4.ToString();
                label5.Text = month5.ToString();
                label6.Text = month6.ToString();
                label12.Text = month7.ToString();
                label13.Text = month8.ToString();
            suma = month + month4;
            resta = month2 - month5;
            do
            {
                month2 = random.Next(1, 9);
                resta = month2 - month5;
            } while (resta <= 0);
            label2.Text = month2.ToString();

            multi = month3 * month6;
            divi = month7 / month8;
            do
            {
                month7 = random.Next(1, 9);
                divi = month7 / month8;
            } while (divi <= 0);
            label12.Text = month7.ToString();
            timer1.Enabled = true;
            button1.Enabled = false;
                
            }
         

        }
    }
