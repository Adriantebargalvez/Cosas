﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        pedido pedido = new pedido();
        double precio = 8;
        double extra = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Hamburgesa_Click(object sender, EventArgs e)
        {
            Hamburgesa formulario=new Hamburgesa(pedido);
            formulario.ShowDialog();
            
        }

        private void Pan_Click(object sender, EventArgs e)
        {
            pan formulario1 = new pan();
            formulario1.ShowDialog();
        }

        private void Patatas_Click(object sender, EventArgs e)
        {
            patatas formulario1 = new patatas(pedido);
            formulario1.ShowDialog();
        }

        private void bebida_Click(object sender, EventArgs e)
        {
            bebida formulario1 = new bebida(pedido);
            formulario1.ShowDialog();
        }

        private void reparto_Click(object sender, EventArgs e)
        {
           Reparto formulario1 = new Reparto(pedido);
            formulario1.ShowDialog();
        }

        private void Calcu_Click(object sender, EventArgs e)
        {

            extra = 0;
            extra +=(double) kepkup.Value * 0.5;
            extra += (double)barba.Value * 0.5;
            extra += (double)Mosta.Value * 0.5;
            if (Hamburgesacheck.Checked)
            {
                extra += 2;
            }
            if (queso.Checked)
            {
                extra += 0.5;
            }
            if (patatasextra.Checked)
            {
                extra += 1;
            }
            extra += pedido.Extrahamburguesa + pedido.Extrabebida + pedido.Tipopatatas;
            double total=precio + extra;
            if (pedido.Reparto)
            {
                total *= 0.8;
            }
            Precio.Text = (total).ToString();
        }
    }
}
