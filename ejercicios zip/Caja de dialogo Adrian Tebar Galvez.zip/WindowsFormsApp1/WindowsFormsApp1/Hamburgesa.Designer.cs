﻿namespace WindowsFormsApp1
{
    partial class Hamburgesa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.salir = new System.Windows.Forms.Button();
            this.pollo = new System.Windows.Forms.CheckBox();
            this.cerdo = new System.Windows.Forms.CheckBox();
            this.Ternera = new System.Windows.Forms.CheckBox();
            this.vegana = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // salir
            // 
            this.salir.Location = new System.Drawing.Point(2, 140);
            this.salir.Name = "salir";
            this.salir.Size = new System.Drawing.Size(140, 32);
            this.salir.TabIndex = 1;
            this.salir.Text = "salir";
            this.salir.UseVisualStyleBackColor = true;
            this.salir.Click += new System.EventHandler(this.button1_Click);
            // 
            // pollo
            // 
            this.pollo.AutoSize = true;
            this.pollo.Location = new System.Drawing.Point(29, 12);
            this.pollo.Name = "pollo";
            this.pollo.Size = new System.Drawing.Size(69, 24);
            this.pollo.TabIndex = 2;
            this.pollo.Text = "Pollo";
            this.pollo.UseVisualStyleBackColor = true;
            this.pollo.CheckedChanged += new System.EventHandler(this.pollo_CheckedChanged);
            // 
            // cerdo
            // 
            this.cerdo.AutoSize = true;
            this.cerdo.Location = new System.Drawing.Point(29, 42);
            this.cerdo.Name = "cerdo";
            this.cerdo.Size = new System.Drawing.Size(78, 24);
            this.cerdo.TabIndex = 3;
            this.cerdo.Text = "Cerdo";
            this.cerdo.UseVisualStyleBackColor = true;
            this.cerdo.CheckedChanged += new System.EventHandler(this.cerdo_CheckedChanged);
            // 
            // Ternera
            // 
            this.Ternera.AutoSize = true;
            this.Ternera.Location = new System.Drawing.Point(29, 72);
            this.Ternera.Name = "Ternera";
            this.Ternera.Size = new System.Drawing.Size(90, 24);
            this.Ternera.TabIndex = 4;
            this.Ternera.Text = "Ternera";
            this.Ternera.UseVisualStyleBackColor = true;
            this.Ternera.CheckedChanged += new System.EventHandler(this.Ternera_CheckedChanged);
            // 
            // vegana
            // 
            this.vegana.AutoSize = true;
            this.vegana.Location = new System.Drawing.Point(29, 102);
            this.vegana.Name = "vegana";
            this.vegana.Size = new System.Drawing.Size(91, 24);
            this.vegana.TabIndex = 5;
            this.vegana.Text = "Vegana";
            this.vegana.UseVisualStyleBackColor = true;
            this.vegana.CheckedChanged += new System.EventHandler(this.vegana_CheckedChanged);
            // 
            // Hamburgesa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(176, 184);
            this.Controls.Add(this.vegana);
            this.Controls.Add(this.Ternera);
            this.Controls.Add(this.cerdo);
            this.Controls.Add(this.pollo);
            this.Controls.Add(this.salir);
            this.Name = "Hamburgesa";
            this.Text = "Hamburgesa";
            this.Load += new System.EventHandler(this.Hamburgesa_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button salir;
        private System.Windows.Forms.CheckBox pollo;
        private System.Windows.Forms.CheckBox cerdo;
        private System.Windows.Forms.CheckBox Ternera;
        private System.Windows.Forms.CheckBox vegana;
    }
}