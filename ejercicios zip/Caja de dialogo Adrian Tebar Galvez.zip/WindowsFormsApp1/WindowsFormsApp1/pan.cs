﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class pan : Form
    {
        public pan()
        {
            InitializeComponent();
        }

        private void Normal_CheckedChanged(object sender, EventArgs e)
        {
            Integral.Checked = false;
            centeno.Checked = false;
        }

        private void Integral_CheckedChanged(object sender, EventArgs e)
        {
            centeno.Checked = false;
            Normal.Checked = false;
        }

        private void centeno_CheckedChanged(object sender, EventArgs e)
        {
            Normal.Checked = false;
            Integral.Checked = false;
        }

        private void Salir_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
