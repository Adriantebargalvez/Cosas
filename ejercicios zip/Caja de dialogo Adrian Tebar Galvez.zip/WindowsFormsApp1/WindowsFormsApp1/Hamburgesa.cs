﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Hamburgesa : Form
    {
        pedido pedido;
        public Hamburgesa(pedido pedido)
        {
            InitializeComponent();
            this.pedido = pedido;
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            pedido.Extrahamburguesa = 0;
            if (Ternera.Checked || vegana.Checked)
            {
                pedido.Extrahamburguesa = 1;
            }

            Close();
        }

        private void pollo_CheckedChanged(object sender, EventArgs e)
        {
           
            cerdo.Checked = false;
            Ternera.Checked = false;
            vegana.Checked = false;
        }

        private void cerdo_CheckedChanged(object sender, EventArgs e)
        {
            pollo.Checked = false;
            Ternera.Checked = false;
            vegana.Checked = false;
        }

        private void Ternera_CheckedChanged(object sender, EventArgs e)
        {
            pollo.Checked = false;
            cerdo.Checked = false;
            vegana.Checked = false;
            if (Ternera.Checked)
            {
                MessageBox.Show("Vale un 1€ adicional");
            }

        }

        private void vegana_CheckedChanged(object sender, EventArgs e)
        {
            
            pollo.Checked = false;
            cerdo.Checked = false;
            Ternera.Checked = false;
            if (vegana.Checked)
            {
                MessageBox.Show("Vale un 1€ adicional");
            }



        }

        private void Hamburgesa_Load(object sender, EventArgs e)
        {

        }
    }
}
