﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class bebida : Form
    {
        pedido pedido;
        public bebida(pedido pedido)
        {
            InitializeComponent();
            this.pedido = pedido;   
        }

        private void Cola_CheckedChanged(object sender, EventArgs e)
        {
            Limon.Checked = false;  
            Naranja.Checked = false;    
            agua.Checked = false;
            Cerveza.Checked=false;
            if (Cola.Checked)
            {
                MessageBox.Show("Estas dispiesto a consumirlo");
            }
        }

        private void Limon_CheckedChanged(object sender, EventArgs e)
        {
            Cola.Checked = false;
            Naranja.Checked = false;
            agua.Checked = false;
            Cerveza.Checked = false;
            if (Limon.Checked)
            {
                MessageBox.Show("Estas dispiesto a consumirlo");
            }
        }

        private void Naranja_CheckedChanged(object sender, EventArgs e)
        {
            Limon.Checked = false;
            Cola.Checked = false;
            agua.Checked = false;
            Cerveza.Checked = false;
            if (Naranja.Checked)
            {
                MessageBox.Show("Estas dispiesto a consumirlo");
            }
        }

        private void agua_CheckedChanged(object sender, EventArgs e)
        {
            Limon.Checked = false;
            Naranja.Checked = false;
            Cola.Checked = false;
            Cerveza.Checked = false;
            if (agua.Checked)
            {
                MessageBox.Show("Estas dispiesto a consumirlo");
            }
        }

        private void Cerveza_CheckedChanged(object sender, EventArgs e)
        {
            Limon.Checked = false;
            Naranja.Checked = false;
            agua.Checked = false;
            Cola.Checked = false;
            if (Cerveza.Checked)
            {
                MessageBox.Show("Estas dispiesto a consumirlo");
            }
        }

        private void salir_Click(object sender, EventArgs e)
        {
            pedido.Extrabebida= 0;
            if (Cerveza.Checked || Cola.Checked || Limon.Checked || Naranja.Checked || agua.Checked)
            {
                pedido.Extrabebida = 1;
            }
            Close();
        }
    }
}
