﻿namespace WindowsFormsApp1
{
    partial class pan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Normal = new System.Windows.Forms.CheckBox();
            this.Integral = new System.Windows.Forms.CheckBox();
            this.centeno = new System.Windows.Forms.CheckBox();
            this.Salir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Normal
            // 
            this.Normal.AutoSize = true;
            this.Normal.Location = new System.Drawing.Point(3, 12);
            this.Normal.Name = "Normal";
            this.Normal.Size = new System.Drawing.Size(85, 24);
            this.Normal.TabIndex = 0;
            this.Normal.Text = "Normal";
            this.Normal.UseVisualStyleBackColor = true;
            this.Normal.CheckedChanged += new System.EventHandler(this.Normal_CheckedChanged);
            // 
            // Integral
            // 
            this.Integral.AutoSize = true;
            this.Integral.Location = new System.Drawing.Point(3, 42);
            this.Integral.Name = "Integral";
            this.Integral.Size = new System.Drawing.Size(89, 24);
            this.Integral.TabIndex = 1;
            this.Integral.Text = "Integral";
            this.Integral.UseVisualStyleBackColor = true;
            this.Integral.CheckedChanged += new System.EventHandler(this.Integral_CheckedChanged);
            // 
            // centeno
            // 
            this.centeno.AutoSize = true;
            this.centeno.Location = new System.Drawing.Point(3, 72);
            this.centeno.Name = "centeno";
            this.centeno.Size = new System.Drawing.Size(96, 24);
            this.centeno.TabIndex = 2;
            this.centeno.Text = "Centeno";
            this.centeno.UseVisualStyleBackColor = true;
            this.centeno.CheckedChanged += new System.EventHandler(this.centeno_CheckedChanged);
            // 
            // Salir
            // 
            this.Salir.Location = new System.Drawing.Point(33, 95);
            this.Salir.Name = "Salir";
            this.Salir.Size = new System.Drawing.Size(110, 27);
            this.Salir.TabIndex = 3;
            this.Salir.Text = "Salir";
            this.Salir.UseVisualStyleBackColor = true;
            this.Salir.Click += new System.EventHandler(this.Salir_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(176, 125);
            this.Controls.Add(this.Salir);
            this.Controls.Add(this.centeno);
            this.Controls.Add(this.Integral);
            this.Controls.Add(this.Normal);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox Normal;
        private System.Windows.Forms.CheckBox Integral;
        private System.Windows.Forms.CheckBox centeno;
        private System.Windows.Forms.Button Salir;
    }
}