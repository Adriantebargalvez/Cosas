﻿namespace WindowsFormsApp1
{
    partial class bebida
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.salir = new System.Windows.Forms.Button();
            this.Cola = new System.Windows.Forms.CheckBox();
            this.Limon = new System.Windows.Forms.CheckBox();
            this.Naranja = new System.Windows.Forms.CheckBox();
            this.agua = new System.Windows.Forms.CheckBox();
            this.Cerveza = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // salir
            // 
            this.salir.Location = new System.Drawing.Point(24, 157);
            this.salir.Name = "salir";
            this.salir.Size = new System.Drawing.Size(99, 28);
            this.salir.TabIndex = 0;
            this.salir.Text = "Salir";
            this.salir.UseVisualStyleBackColor = true;
            this.salir.Click += new System.EventHandler(this.salir_Click);
            // 
            // Cola
            // 
            this.Cola.AutoSize = true;
            this.Cola.Location = new System.Drawing.Point(12, 5);
            this.Cola.Name = "Cola";
            this.Cola.Size = new System.Drawing.Size(67, 24);
            this.Cola.TabIndex = 1;
            this.Cola.Text = "Cola";
            this.Cola.UseVisualStyleBackColor = true;
            this.Cola.CheckedChanged += new System.EventHandler(this.Cola_CheckedChanged);
            // 
            // Limon
            // 
            this.Limon.AutoSize = true;
            this.Limon.Location = new System.Drawing.Point(12, 35);
            this.Limon.Name = "Limon";
            this.Limon.Size = new System.Drawing.Size(78, 24);
            this.Limon.TabIndex = 2;
            this.Limon.Text = "Limon";
            this.Limon.UseVisualStyleBackColor = true;
            this.Limon.CheckedChanged += new System.EventHandler(this.Limon_CheckedChanged);
            // 
            // Naranja
            // 
            this.Naranja.AutoSize = true;
            this.Naranja.Location = new System.Drawing.Point(12, 65);
            this.Naranja.Name = "Naranja";
            this.Naranja.Size = new System.Drawing.Size(90, 24);
            this.Naranja.TabIndex = 3;
            this.Naranja.Text = "Naranja";
            this.Naranja.UseVisualStyleBackColor = true;
            this.Naranja.CheckedChanged += new System.EventHandler(this.Naranja_CheckedChanged);
            // 
            // agua
            // 
            this.agua.AutoSize = true;
            this.agua.Location = new System.Drawing.Point(12, 95);
            this.agua.Name = "agua";
            this.agua.Size = new System.Drawing.Size(73, 24);
            this.agua.TabIndex = 4;
            this.agua.Text = "Agua";
            this.agua.UseVisualStyleBackColor = true;
            this.agua.CheckedChanged += new System.EventHandler(this.agua_CheckedChanged);
            // 
            // Cerveza
            // 
            this.Cerveza.AutoSize = true;
            this.Cerveza.Location = new System.Drawing.Point(12, 127);
            this.Cerveza.Name = "Cerveza";
            this.Cerveza.Size = new System.Drawing.Size(93, 24);
            this.Cerveza.TabIndex = 5;
            this.Cerveza.Text = "Cerveza";
            this.Cerveza.UseVisualStyleBackColor = true;
            this.Cerveza.CheckedChanged += new System.EventHandler(this.Cerveza_CheckedChanged);
            // 
            // bebida
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(176, 193);
            this.Controls.Add(this.Cerveza);
            this.Controls.Add(this.agua);
            this.Controls.Add(this.Naranja);
            this.Controls.Add(this.Limon);
            this.Controls.Add(this.Cola);
            this.Controls.Add(this.salir);
            this.Name = "bebida";
            this.Text = "bebida";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button salir;
        private System.Windows.Forms.CheckBox Cola;
        private System.Windows.Forms.CheckBox Limon;
        private System.Windows.Forms.CheckBox Naranja;
        private System.Windows.Forms.CheckBox agua;
        private System.Windows.Forms.CheckBox Cerveza;
    }
}