﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class patatas : Form
    {
        pedido pedido;
        public patatas(pedido pedido)
        {
            InitializeComponent();
            this.pedido = pedido;
        }

        private void fritas_CheckedChanged(object sender, EventArgs e)
        {
            gajo.Checked = false;
            Caseras.Checked = false;
        }

        private void gajo_CheckedChanged(object sender, EventArgs e)
        {
            fritas.Checked = false;
            Caseras.Checked = false;
        }

        private void Caseras_CheckedChanged(object sender, EventArgs e)
        {
            gajo.Checked = false;
            fritas.Checked = false;
            if (Caseras.Checked)
            {
                MessageBox.Show("Vale 1€ aparte");
            }
        }

        private void Salir_Click(object sender, EventArgs e)
        {
            pedido.Tipopatatas = 0;
            if (Caseras.Checked)
            {
                pedido.Tipopatatas = 1;
            }
            Close();
        }
    }
}
