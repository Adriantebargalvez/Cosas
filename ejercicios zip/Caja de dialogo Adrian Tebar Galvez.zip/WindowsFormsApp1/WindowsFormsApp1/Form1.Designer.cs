﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.Hamburgesa = new System.Windows.Forms.Button();
            this.Pan = new System.Windows.Forms.Button();
            this.Patatas = new System.Windows.Forms.Button();
            this.bebida = new System.Windows.Forms.Button();
            this.menu = new System.Windows.Forms.Label();
            this.opciones = new System.Windows.Forms.Label();
            this.Salsa = new System.Windows.Forms.Label();
            this.kepkup = new System.Windows.Forms.NumericUpDown();
            this.barba = new System.Windows.Forms.NumericUpDown();
            this.Mosta = new System.Windows.Forms.NumericUpDown();
            this.keptup = new System.Windows.Forms.Label();
            this.Barbacoa = new System.Windows.Forms.Label();
            this.Mostaza = new System.Windows.Forms.Label();
            this.Hamburgesacheck = new System.Windows.Forms.CheckBox();
            this.queso = new System.Windows.Forms.CheckBox();
            this.patatasextra = new System.Windows.Forms.CheckBox();
            this.reparto = new System.Windows.Forms.Button();
            this.Calcu = new System.Windows.Forms.Button();
            this.Precio = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.kepkup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barba)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Mosta)).BeginInit();
            this.SuspendLayout();
            // 
            // Hamburgesa
            // 
            this.Hamburgesa.Location = new System.Drawing.Point(89, 72);
            this.Hamburgesa.Name = "Hamburgesa";
            this.Hamburgesa.Size = new System.Drawing.Size(124, 46);
            this.Hamburgesa.TabIndex = 0;
            this.Hamburgesa.Text = "Hamburgesa";
            this.Hamburgesa.UseVisualStyleBackColor = true;
            this.Hamburgesa.Click += new System.EventHandler(this.Hamburgesa_Click);
            // 
            // Pan
            // 
            this.Pan.Location = new System.Drawing.Point(253, 72);
            this.Pan.Name = "Pan";
            this.Pan.Size = new System.Drawing.Size(124, 46);
            this.Pan.TabIndex = 1;
            this.Pan.Text = "Pan";
            this.Pan.UseVisualStyleBackColor = true;
            this.Pan.Click += new System.EventHandler(this.Pan_Click);
            // 
            // Patatas
            // 
            this.Patatas.Location = new System.Drawing.Point(417, 72);
            this.Patatas.Name = "Patatas";
            this.Patatas.Size = new System.Drawing.Size(124, 46);
            this.Patatas.TabIndex = 2;
            this.Patatas.Text = "Patatas";
            this.Patatas.UseVisualStyleBackColor = true;
            this.Patatas.Click += new System.EventHandler(this.Patatas_Click);
            // 
            // bebida
            // 
            this.bebida.Location = new System.Drawing.Point(582, 72);
            this.bebida.Name = "bebida";
            this.bebida.Size = new System.Drawing.Size(124, 46);
            this.bebida.TabIndex = 3;
            this.bebida.Text = "bebida";
            this.bebida.UseVisualStyleBackColor = true;
            this.bebida.Click += new System.EventHandler(this.bebida_Click);
            // 
            // menu
            // 
            this.menu.AutoSize = true;
            this.menu.Location = new System.Drawing.Point(85, 2);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(123, 20);
            this.menu.TabIndex = 4;
            this.menu.Text = "Menu Basico 8€";
            // 
            // opciones
            // 
            this.opciones.AutoSize = true;
            this.opciones.Location = new System.Drawing.Point(85, 156);
            this.opciones.Name = "opciones";
            this.opciones.Size = new System.Drawing.Size(189, 20);
            this.opciones.TabIndex = 5;
            this.opciones.Text = "Opciones extras/adicional";
            // 
            // Salsa
            // 
            this.Salsa.AutoSize = true;
            this.Salsa.Location = new System.Drawing.Point(483, 156);
            this.Salsa.Name = "Salsa";
            this.Salsa.Size = new System.Drawing.Size(155, 20);
            this.Salsa.TabIndex = 6;
            this.Salsa.Text = "Salsa( 0,5 cada una)";
            // 
            // kepkup
            // 
            this.kepkup.Location = new System.Drawing.Point(612, 203);
            this.kepkup.Name = "kepkup";
            this.kepkup.Size = new System.Drawing.Size(39, 26);
            this.kepkup.TabIndex = 7;
            // 
            // barba
            // 
            this.barba.Location = new System.Drawing.Point(612, 250);
            this.barba.Name = "barba";
            this.barba.Size = new System.Drawing.Size(39, 26);
            this.barba.TabIndex = 8;
            // 
            // Mosta
            // 
            this.Mosta.Location = new System.Drawing.Point(612, 295);
            this.Mosta.Name = "Mosta";
            this.Mosta.Size = new System.Drawing.Size(39, 26);
            this.Mosta.TabIndex = 9;
            // 
            // keptup
            // 
            this.keptup.AutoSize = true;
            this.keptup.Location = new System.Drawing.Point(499, 209);
            this.keptup.Name = "keptup";
            this.keptup.Size = new System.Drawing.Size(58, 20);
            this.keptup.TabIndex = 10;
            this.keptup.Text = "keptup";
            // 
            // Barbacoa
            // 
            this.Barbacoa.AutoSize = true;
            this.Barbacoa.Location = new System.Drawing.Point(499, 252);
            this.Barbacoa.Name = "Barbacoa";
            this.Barbacoa.Size = new System.Drawing.Size(78, 20);
            this.Barbacoa.TabIndex = 11;
            this.Barbacoa.Text = "Barbacoa";
            // 
            // Mostaza
            // 
            this.Mostaza.AutoSize = true;
            this.Mostaza.Location = new System.Drawing.Point(499, 301);
            this.Mostaza.Name = "Mostaza";
            this.Mostaza.Size = new System.Drawing.Size(70, 20);
            this.Mostaza.TabIndex = 12;
            this.Mostaza.Text = "Mostaza";
            // 
            // Hamburgesacheck
            // 
            this.Hamburgesacheck.AutoSize = true;
            this.Hamburgesacheck.Location = new System.Drawing.Point(89, 203);
            this.Hamburgesacheck.Name = "Hamburgesacheck";
            this.Hamburgesacheck.Size = new System.Drawing.Size(205, 24);
            this.Hamburgesacheck.TabIndex = 13;
            this.Hamburgesacheck.Text = "Hamburgesa Doble (2€)";
            this.Hamburgesacheck.UseVisualStyleBackColor = true;
            // 
            // queso
            // 
            this.queso.AutoSize = true;
            this.queso.Location = new System.Drawing.Point(89, 250);
            this.queso.Name = "queso";
            this.queso.Size = new System.Drawing.Size(192, 24);
            this.queso.TabIndex = 14;
            this.queso.Text = "Extra de queso(+0,50)";
            this.queso.UseVisualStyleBackColor = true;
            // 
            // patatasextra
            // 
            this.patatasextra.AutoSize = true;
            this.patatasextra.Location = new System.Drawing.Point(89, 297);
            this.patatasextra.Name = "patatasextra";
            this.patatasextra.Size = new System.Drawing.Size(180, 24);
            this.patatasextra.TabIndex = 15;
            this.patatasextra.Text = "Extra de patatas(+1)";
            this.patatasextra.UseVisualStyleBackColor = true;
            // 
            // reparto
            // 
            this.reparto.Location = new System.Drawing.Point(328, 335);
            this.reparto.Name = "reparto";
            this.reparto.Size = new System.Drawing.Size(87, 38);
            this.reparto.TabIndex = 16;
            this.reparto.Text = "Reparto";
            this.reparto.UseVisualStyleBackColor = true;
            this.reparto.Click += new System.EventHandler(this.reparto_Click);
            // 
            // Calcu
            // 
            this.Calcu.Location = new System.Drawing.Point(194, 383);
            this.Calcu.Name = "Calcu";
            this.Calcu.Size = new System.Drawing.Size(87, 38);
            this.Calcu.TabIndex = 18;
            this.Calcu.Text = "Calcu";
            this.Calcu.UseVisualStyleBackColor = true;
            this.Calcu.Click += new System.EventHandler(this.Calcu_Click);
            // 
            // Precio
            // 
            this.Precio.AutoSize = true;
            this.Precio.Location = new System.Drawing.Point(362, 392);
            this.Precio.Name = "Precio";
            this.Precio.Size = new System.Drawing.Size(53, 20);
            this.Precio.TabIndex = 19;
            this.Precio.Text = "Precio";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Precio);
            this.Controls.Add(this.Calcu);
            this.Controls.Add(this.reparto);
            this.Controls.Add(this.patatasextra);
            this.Controls.Add(this.queso);
            this.Controls.Add(this.Hamburgesacheck);
            this.Controls.Add(this.Mostaza);
            this.Controls.Add(this.Barbacoa);
            this.Controls.Add(this.keptup);
            this.Controls.Add(this.Mosta);
            this.Controls.Add(this.barba);
            this.Controls.Add(this.kepkup);
            this.Controls.Add(this.Salsa);
            this.Controls.Add(this.opciones);
            this.Controls.Add(this.menu);
            this.Controls.Add(this.bebida);
            this.Controls.Add(this.Patatas);
            this.Controls.Add(this.Pan);
            this.Controls.Add(this.Hamburgesa);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.kepkup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barba)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Mosta)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Hamburgesa;
        private System.Windows.Forms.Button Pan;
        private System.Windows.Forms.Button Patatas;
        private System.Windows.Forms.Button bebida;
        private System.Windows.Forms.Label menu;
        private System.Windows.Forms.Label opciones;
        private System.Windows.Forms.Label Salsa;
        private System.Windows.Forms.NumericUpDown kepkup;
        private System.Windows.Forms.NumericUpDown barba;
        private System.Windows.Forms.NumericUpDown Mosta;
        private System.Windows.Forms.Label keptup;
        private System.Windows.Forms.Label Barbacoa;
        private System.Windows.Forms.Label Mostaza;
        private System.Windows.Forms.CheckBox Hamburgesacheck;
        private System.Windows.Forms.CheckBox queso;
        private System.Windows.Forms.CheckBox patatasextra;
        private System.Windows.Forms.Button reparto;
        private System.Windows.Forms.Button Calcu;
        private System.Windows.Forms.Label Precio;
    }
}

