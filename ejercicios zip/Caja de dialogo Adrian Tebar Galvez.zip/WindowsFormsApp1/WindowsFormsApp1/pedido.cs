﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class pedido
    {
        double extrabebida = 0, extrahamburguesa = 0, tipopatatas=0;
        bool reparto=false;

        public double Extrabebida { get => extrabebida; set => extrabebida = value; }
        public double Extrahamburguesa { get => extrahamburguesa; set => extrahamburguesa = value; }
        public double Tipopatatas { get => tipopatatas; set => tipopatatas = value; }
        public bool Reparto { get => reparto; set => reparto = value; }
    }
}
