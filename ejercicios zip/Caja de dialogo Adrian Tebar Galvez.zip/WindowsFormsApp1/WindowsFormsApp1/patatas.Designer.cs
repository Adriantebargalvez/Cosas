﻿namespace WindowsFormsApp1
{
    partial class patatas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fritas = new System.Windows.Forms.CheckBox();
            this.gajo = new System.Windows.Forms.CheckBox();
            this.Caseras = new System.Windows.Forms.CheckBox();
            this.Salir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // fritas
            // 
            this.fritas.AutoSize = true;
            this.fritas.Location = new System.Drawing.Point(25, 22);
            this.fritas.Name = "fritas";
            this.fritas.Size = new System.Drawing.Size(75, 24);
            this.fritas.TabIndex = 0;
            this.fritas.Text = "Fritas";
            this.fritas.UseVisualStyleBackColor = true;
            this.fritas.CheckedChanged += new System.EventHandler(this.fritas_CheckedChanged);
            // 
            // gajo
            // 
            this.gajo.AutoSize = true;
            this.gajo.Location = new System.Drawing.Point(25, 52);
            this.gajo.Name = "gajo";
            this.gajo.Size = new System.Drawing.Size(69, 24);
            this.gajo.TabIndex = 1;
            this.gajo.Text = "Gajo";
            this.gajo.UseVisualStyleBackColor = true;
            this.gajo.CheckedChanged += new System.EventHandler(this.gajo_CheckedChanged);
            // 
            // Caseras
            // 
            this.Caseras.AutoSize = true;
            this.Caseras.Location = new System.Drawing.Point(25, 82);
            this.Caseras.Name = "Caseras";
            this.Caseras.Size = new System.Drawing.Size(131, 24);
            this.Caseras.TabIndex = 2;
            this.Caseras.Text = "Caseras(+1€)";
            this.Caseras.UseVisualStyleBackColor = true;
            this.Caseras.CheckedChanged += new System.EventHandler(this.Caseras_CheckedChanged);
            // 
            // Salir
            // 
            this.Salir.Location = new System.Drawing.Point(25, 112);
            this.Salir.Name = "Salir";
            this.Salir.Size = new System.Drawing.Size(94, 25);
            this.Salir.TabIndex = 3;
            this.Salir.Text = "Salir";
            this.Salir.UseVisualStyleBackColor = true;
            this.Salir.Click += new System.EventHandler(this.Salir_Click);
            // 
            // patatas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Salir);
            this.Controls.Add(this.Caseras);
            this.Controls.Add(this.gajo);
            this.Controls.Add(this.fritas);
            this.Name = "patatas";
            this.Text = "patatas";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox fritas;
        private System.Windows.Forms.CheckBox gajo;
        private System.Windows.Forms.CheckBox Caseras;
        private System.Windows.Forms.Button Salir;
    }
}