﻿namespace WindowsFormsApp1
{
    partial class Reparto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Salir = new System.Windows.Forms.Button();
            this.Recogida = new System.Windows.Forms.CheckBox();
            this.domicilio = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // Salir
            // 
            this.Salir.Location = new System.Drawing.Point(33, 72);
            this.Salir.Name = "Salir";
            this.Salir.Size = new System.Drawing.Size(148, 29);
            this.Salir.TabIndex = 0;
            this.Salir.Text = "Salir";
            this.Salir.UseVisualStyleBackColor = true;
            this.Salir.Click += new System.EventHandler(this.Salir_Click);
            // 
            // Recogida
            // 
            this.Recogida.AutoSize = true;
            this.Recogida.Location = new System.Drawing.Point(12, 12);
            this.Recogida.Name = "Recogida";
            this.Recogida.Size = new System.Drawing.Size(221, 24);
            this.Recogida.TabIndex = 1;
            this.Recogida.Text = "Recogida en local(-20 dto)";
            this.Recogida.UseVisualStyleBackColor = true;
            this.Recogida.CheckedChanged += new System.EventHandler(this.Recogida_CheckedChanged);
            // 
            // domicilio
            // 
            this.domicilio.AutoSize = true;
            this.domicilio.Location = new System.Drawing.Point(12, 42);
            this.domicilio.Name = "domicilio";
            this.domicilio.Size = new System.Drawing.Size(110, 24);
            this.domicilio.TabIndex = 2;
            this.domicilio.Text = "A domicilio";
            this.domicilio.UseVisualStyleBackColor = true;
            this.domicilio.CheckedChanged += new System.EventHandler(this.domicilio_CheckedChanged);
            // 
            // Reparto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(229, 107);
            this.Controls.Add(this.domicilio);
            this.Controls.Add(this.Recogida);
            this.Controls.Add(this.Salir);
            this.Name = "Reparto";
            this.Text = "Reparto";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Salir;
        private System.Windows.Forms.CheckBox Recogida;
        private System.Windows.Forms.CheckBox domicilio;
    }
}