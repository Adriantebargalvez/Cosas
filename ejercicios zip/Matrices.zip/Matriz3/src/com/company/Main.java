package com.company;

import java.util.concurrent.ThreadLocalRandom;

public class Main {

    static public double calcumedia(int matriz [][]){
        double media = 0;
        for (int x = 0; x < 3; x++) {

            for (int y = 0; y < 3; y++) {
                media+=matriz[x][y];


            }

        }
        return media/9;


    }
    static public double max( int matriz[][]) {
        int max = 0;
        for (int x = 0; x < 3; x++) {

            for (int y = 0; y < 3; y++) {
if (matriz[x][y]>max){
    max=matriz[x][y];
}
            }
        }
              return max;
    }
    static public double min( int matriz[][]) {
        int min = 0;
        for (int x = 0; x < 3; x++) {

            for (int y = 0; y < 3; y++) {
                if (matriz[x][y]<min){
                    min=matriz[x][y];
                }
            }
        }
        return min;
    }
    static public double descendente (int matriz[][] ){
        int suma=0;
        for (int x = 0; x < 3; x++) {

            for (int y = 0; y < 3; y++) {
                suma=matriz[0][0] + matriz[1][1] + matriz[2][2];
            }
            }
return suma;
    }
    static public double ascendente (int matriz[][] ){
        int suma1=0;
        for (int x = 0; x < 3; x++) {

            for (int y = 0; y < 3; y++) {
                suma1=matriz[2][0] + matriz[1][1] + matriz[0][2];
            }
        }
        return suma1;
    }
    static public double descendentedebajo (int matriz[][] ){
        int suma2=0;
        for (int x = 0; x < 3; x++) {

            for (int y = 0; y < 3; y++) {
                suma2=matriz[2][0] + matriz[2][1] + matriz[2][2];
            }
        }
        return suma2;
    }
    static public double descendentearriba (int matriz[][] ){
        int suma3=0;
        for (int x = 0; x < 3; x++) {

            for (int y = 0; y < 3; y++) {
                suma3=matriz[0][0] + matriz[0][1] + matriz[0][2];
            }
        }
        return suma3;
    }
    public static void main(String[] args) {

int opcion = 0;
        int[][] matriz ={
                {1,2,3},
                {4,5,6},
                {9,8,7},
        };
        System.out.printf("Media %.2f: \n ",calcumedia(matriz));
        System.out.printf("Maximo: ");
        System.out.println(max(matriz));
        System.out.printf("Minimo: ");
        System.out.println(min(matriz));
        System.out.printf("Suma descendente: ");
        System.out.println(descendente(matriz));
        System.out.printf("Suma ascendente: ");
        System.out.println(ascendente(matriz));
        System.out.printf("Suma descendente arriba: ");
        System.out.println(descendentearriba(matriz));
        System.out.printf("Suma descendente debajo: ");
        System.out.println(descendentedebajo(matriz));
    }
}

