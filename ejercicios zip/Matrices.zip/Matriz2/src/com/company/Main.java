package com.company;

import java.util.Scanner;

public class Main {
    static public Scanner sc =new Scanner(System.in);
    static   String castellano = "",mates="",valen="",bio="";
    static   int nota1,nota2,nota3,nota4;
static public String alumno1 (){
    System.out.println("Castellano");
    nota1= sc.nextInt();
    System.out.println("Mates");
    nota2= sc.nextInt();
    System.out.println("Valen");
    nota3= sc.nextInt();
    System.out.println("bio");
    nota4= sc.nextInt();
return "castellano";
}
static public int media(){
    return (nota1+nota2+nota3+nota4)/4;
}
    static public int min( int array[]) {
        int min = array[0];
        for (int x = 1; x < 4; x++) {


                if (array[x]<min){
                    min=array[x];
                }
            }

        return min;
    }
    static public int max( int array[]) {
        int max = array[0];
        for (int x = 1; x < 4; x++) {

            if (array[x]>max){
                max=array[x];
                }

            }

        return max;
    }
    public static void main(String[] args) {

        int matriz[][] = new int[4][5];

        alumno1();
        int array[]={nota1,nota2,nota3,nota4};
        System.out.println(media());
        System.out.println(min(array));
        System.out.printf("%d %d %d %d \n",nota1,nota2,nota3,nota4);
        System.out.println(max(array));
    }

}
