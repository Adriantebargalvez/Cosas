package com.company;

import java.util.concurrent.ThreadLocalRandom;

public class Main {

    public static void main(String[] args) {
        // write your code here
        String array="";
        System.out.println();
        int matriz[][] = new int[8][5];
        for (int x = 0; x < 8; x++) {

            for (int y = 0; y < 5; y++){
                int random = ThreadLocalRandom.current().nextInt(1,51);
                matriz[x][y]=random;
                array+= matriz[x][y] + " " ;


            }
            array+="\n";

        }
        System.out.println(array);
    }
}