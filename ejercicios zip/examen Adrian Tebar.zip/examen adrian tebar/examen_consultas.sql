-- 1. Calcula cuántos alumnos nacieron en cada año.
select year(fecha_nacimiento) as anio_nacimiento, count(*) as cantidad_alumnos
from alumno
group by year(fecha_nacimiento);
-- 2. Devuelve un listado con los profesores que tienen un departamento asociado y que
-- no imparten ninguna asignatura.
select p.id, p.nombre, p.apellido1, p.apellido2, d.nombre
from profesor p
join despartamento d on p.iddepartamento = d.id
left join asignatura a on p.id = a.idprofe
where a.idprofe is null ;

-- 3. Averigua el nombre y los dos apellidos de los alumnos que no han dado de alta su
-- número de teléfono en la base de datos.
select nombre,apellido1,apellido2 from  alumno where telefono is null;

-- 4. Devuelve todos los datos del alumno más joven.
select * from alumno
where fecha_nacimiento = (select max(fecha_nacimiento) from alumno);

-- 5. Devuelve el listado de las asignaturas que se imparten en el primer cuatrimestre, en
-- el tercer curso del grado de Biotecnología.
SELECT *
FROM asignatura
WHERE cuatrimestre = 1 AND curso = 3
AND idgrado = (SELECT id FROM grado WHERE nombre = 'Biotecnología');
-- 6. Devuelve un listado con los datos de todas las alumnas que se han matriculado
-- alguna vez en Estructura y tecnología de computadores
select * from alumno, asignatura
where sexo='M' and asignatura.nombre='Estructura y tecnología de computadores';

-- 7. Devuelve el listado de profesores que no han dado de alta su número de teléfono
-- en la base de datos y además su NIF termina en W.
select * from profesor where telefono is null and nif like '%W';

-- 8. Devuelve un listado con el nombre de todos los departamentos que tienen
-- profesores que imparten alguna asignatura en el Grado en Matemáticas (Plan 2010)
select d.nombre
from despartamento d,grado g
where g.nombre = 'Grado en Matemáticas (Plan 2010)'
group by d.nombre;

-- 9. Devuelve un listado con los profesores que no imparten ninguna asignatura.
select * from profesor,asignatura where asignatura.id=null

-- 10. Devuelve un listado con las asignaturas que no tienen un profesor asignado.

-- 11. Devuelve un listado con todos los departamentos que tienen alguna asignatura que
-- se haya impartido en el curso escolar 2015-2016. El resultado debe mostrar el
-- nombre del departamento y el nombre de las asignaturas.

-- 12. Devuelve el número total de alumnas que hay matriculadas en Ingeniería Genética.

-- 13. Devuelve un listado con todos los departamentos y el número de profesores que
-- hay en cada uno de ellos. Tenga en cuenta que pueden existir departamentos que
-- no tienen profesores asociados. Estos departamentos también tienen que aparecer
-- en el listado.

-- 14. Devuelve un listado con el nombre de todos los grados existentes en la base de
-- datos y el número de asignaturas que tiene cada uno, de los grados que tengan
-- más de 40 asignaturas asociadas.

-- 15. Devuelve un listado que muestre cuántos alumnos se han matriculado de alguna
-- asignatura en cada uno de los cursos escolares. El resultado deberá mostrar dos
-- columnas, una columna con el año de inicio del curso escolar y otra con el número
-- de alumnos matriculados.
-- 16. Calcula cuántos profesores hay en cada departamento. El resultado sólo debe
-- mostrar dos columnas, una con el nombre del departamento y otra con el número
-- de profesores que hay en ese departamento. El resultado sólo debe incluir los
-- departamentos que tienen profesores asociados y deberá estar ordenado de mayor
-- a menor por el número de profesores.

-- 17. Devuelve un listado con el número de asignaturas que imparte cada profesor. El
-- listado debe tener en cuenta aquellos profesores que no imparten ninguna
-- asignatura. El resultado mostrará cinco columnas: id, nombre, primer apellido,
-- segundo apellido y número de asignaturas. El resultado estará ordenado de mayor a
-- menor por el número de asignaturas.

-- 18. Devuelve un listado que muestre el nombre de los grados y la suma del número
-- total de créditos que hay para cada tipo de asignatura. El resultado debe tener tres
-- columnas: nombre del grado, tipo de asignatura y la suma de los créditos de todas
-- las asignaturas que hay de ese tipo. Ordene el resultado de mayor a menor por el
-- número total de créditos.

-- 19. Devuelve un listado con los nombres de todos los profesores y los departamentos
-- que tienen vinculados. El listado también debe mostrar aquellos profesores que no
-- tienen ningún departamento asociado. El listado debe devolver cuatro columnas,
-- nombre del departamento, primer apellido, segundo apellido y nombre del
-- profesor. El resultado estará ordenado alfabéticamente de menor a mayor por el
-- nombre del departamento, apellidos y el nombre del profesor.


-- 20. Devuelve un listado con el nombre de todos los grados existentes en la base de
-- datos y el número de asignaturas que tiene cada uno. Tenga en cuenta que pueden
-- existir grados que no tienen asignaturas asociadas. Estos grados también tienen que
-- aparecer en el listado. El resultado deberá estar ordenado de mayor a menor por el
-- número de asignaturas.