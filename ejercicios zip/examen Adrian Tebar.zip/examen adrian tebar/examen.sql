DROP DATABASE IF EXISTS examen;
CREATE DATABASE examen CHARACTER SET utf8mb4;
USE examen;
create table profesor(
id int not null ,
nif varchar(25) not null ,
nombre VARCHAR(25) NOT NULL,
apellido1 VARCHAR(25) NOT NULL,
apellido2 VARCHAR(25) NOT NULL,
ciudad VARCHAR(30) NOT NULL,
direccion VARCHAR(50) NOT NULL,
telefono VARCHAR(20) ,
fecha_nacimiento varchar(25) not null ,
sexo varchar(1) not null,
iddepartamento int
);
create table despartamento(
 id int not null ,
nombre VARCHAR(25) NOT NULL

);
create table asignatura(
 id int not null ,
nombre VARCHAR(100) NOT NULL,
creditos int not null,
tipo varchar(25)not null ,
curso int not null,
cuatrimestre int not null,
idprofe int,
idgrado int
);

create table alumno_asignaturas(
id_alumno int not null,
id_asignaturas int not null,
id_curso_escolar int not null
);

create table grado(
id int not null,
nombre varchar(100) not null
);
create table alumno(
id int not null ,
nif varchar(25) not null ,
nombre VARCHAR(25) NOT NULL,
apellido1 VARCHAR(25) NOT NULL,
apellido2 VARCHAR(25) NOT NULL,
ciudad VARCHAR(30) NOT NULL,
direccion VARCHAR(50) NOT NULL,
telefono VARCHAR(20),
fecha_nacimiento varchar(25) not null ,
sexo varchar(1) not null
);
create table curso(
id int not null,
anyo_inicio int not null,
anyo_fin int not null
);

