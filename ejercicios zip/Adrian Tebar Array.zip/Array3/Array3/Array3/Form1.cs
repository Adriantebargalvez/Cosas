﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Array3
{
    public partial class Form1 : Form
    {
        double n;
       double[] adri = new double[7];
        int contador = 0;
        double suma = 0.0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < adri.Length; i++)
                //trypase hace que si puede pasar a numero lo pasa en tru y sino le puedes añadir que te saque contador
                if (contador < 7 && double.TryParse(textBox1.Text, out adri[contador]))
                {

                    label1.Text = adri[contador].ToString();

                    suma += adri[contador];
                    label2.Text = suma.ToString();
                    textBox1.Text = "";
                    contador++;

                }
            if (contador == 7)
            {
                label2.Text = (suma / 7).ToString();

                button1.Enabled = false;
                textBox1.Enabled = false;
            }

        }
    }
}
