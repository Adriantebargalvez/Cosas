﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Array1
{
    public partial class Form1 : Form
    {
        String[] adri = new String[10];
        int contador=0;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (contador < 10)
            {
                
                adri[contador] = textBox1.Text;
                label1.Text = adri[contador].ToString();
                label2.Text += adri[contador].ToString() + "\n";
                contador++;
                textBox1.Text = "";
            }
            else
            {
               bool button1= false;
              
               bool textBox1 = false;
                
            }

            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           
        }
    }
}
