﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace array4
{
    public partial class Form1 : Form
    {
        Random random = new Random();
        int randomNumber;
        int n;
        int[] numeroaleatorio;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //intenta convertir en numero si puede te da tru y te saca el resultado si quieres si no lo consigue te dara false
           Int32.TryParse(textBox1.Text, out n);
            numeroaleatorio = new int[n];
           
            for (int i = 0; i < n; i++)
            {
                randomNumber = random.Next(0,100);
                numeroaleatorio[i] = randomNumber;
            }
            Array.Sort(numeroaleatorio);
            //une los elementos de la array separado por el separador que pongas en este caso ","
            label2.Text = string.Join(", ", numeroaleatorio);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
