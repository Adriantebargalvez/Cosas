﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace array6
{
    public partial class Form1 : Form
    {
        int n;
        int contador = 0;
        string[] mes = { "Enero", "Febrero", "Marzo" };
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Int32.TryParse(textBox1.Text, out n))
            {
                textBox1.Text = "introduce un numero";
            
                if (n > 0 && n <= 12)
                {

                    
                    label2.Text = mes[n -1];

                }
                else
                {
                    textBox1.Text = "no se puede";
                }

            }
        }
    }
}