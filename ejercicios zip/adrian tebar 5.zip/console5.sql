DROP DATABASE IF EXISTS empleados;
CREATE DATABASE empleados;
USE empleados;
CREATE TABLE departamento (
codigo INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
nombre VARCHAR(100) NOT NULL,
presupuesto DOUBLE UNSIGNED NOT NULL,
gastos DOUBLE UNSIGNED NOT NULL
);
CREATE TABLE empleado (
codigo INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
nif VARCHAR(9) NOT NULL UNIQUE,
nombre VARCHAR(100) NOT NULL,
apellido1 VARCHAR(100) NOT NULL,
apellido2 VARCHAR(100),
codigo_departamento INT UNSIGNED,
FOREIGN KEY (codigo_departamento) REFERENCES departamento(codigo)
);
INSERT INTO departamento VALUES(1, 'Desarrollo', 120000, 6000);
INSERT INTO departamento VALUES(2, 'Sistemas', 150000, 21000);
INSERT INTO departamento VALUES(3, 'Recursos Humanos', 280000, 25000);
INSERT INTO departamento VALUES(4, 'Contabilidad', 110000, 3000);
INSERT INTO departamento VALUES(5, 'I+D', 375000, 380000);
INSERT INTO departamento VALUES(6, 'Proyectos', 0, 0);
INSERT INTO departamento VALUES(7, 'Publicidad', 0, 1000);
INSERT INTO empleado VALUES(1, '32481596F', 'Aarón', 'Rivero', 'Gómez', 1);
INSERT INTO empleado VALUES(2, 'Y5575632D', 'Adela', 'Salas', 'Díaz', 2);
INSERT INTO empleado VALUES(3, 'R6970642B', 'Adolfo', 'Rubio', 'Flores', 3);
INSERT INTO empleado VALUES(4, '77705545E', 'Adrián', 'Suárez', NULL, 4);
INSERT INTO empleado VALUES(5, '17087203C', 'Marcos', 'Loyola', 'Méndez', 5);
INSERT INTO empleado VALUES(6, '38382980M', 'María', 'Santana', 'Moreno', 1);
INSERT INTO empleado VALUES(7, '80576669X', 'Pilar', 'Ruiz', NULL, 2);
INSERT INTO empleado VALUES(8, '71651431Z', 'Pepe', 'Ruiz', 'Santana', 3);
INSERT INTO empleado VALUES(9, '56399183D', 'Juan', 'Gómez', 'López', 2);
INSERT INTO empleado VALUES(10, '46384486H', 'Diego','Flores', 'Salas', 5);

INSERT INTO empleado VALUES(11, '67389283A', 'Marta','Herrera', 'Gil', 1);
INSERT INTO empleado VALUES(12, '41234836R', 'Irene','Salas', 'Flores',
NULL);
INSERT INTO empleado VALUES(13, '82635162B', 'Juan Antonio','Sáez',
'Guerrero', NULL);
-- 1. Devuelve un listado con los empleados y los datos de los departamentos donde trabaja cada uno.

select * ,empleado.nombre  from empleado, departamento;
-- 2. Devuelve un listado con los empleados y los datos de los departamentos donde trabaja cada uno. Ordena el resultado, en primer lugar por el nombre del departamento (en orden alfabético) y en segundo lugar por los apellidos y el nombre de los empleados.

select departamento.nombre,apellido2,apellido1,empleado.nombre,gastos from empleado, departamento order by departamento.nombre;

-- 3. Devuelve un listado con el código y el nombre del departamento, solamente de aquellos departamentos que tienen empleados.

SELECT departamento.codigo,departamento.nombre FROM departamento inner join  empleado on departamento.codigo = empleado.codigo_departamento;

-- 4. Devuelve un listado con el código, el nombre del departamento y el valor del presupuesto actual del que dispone, solamente de aquellos departamentos que tienen empleados. El valor del presupuesto actual lo puede calcular restando al valor del presupuesto inicial (columna presupuesto) el valor de los gastos que ha generado (columna gastos).



-- 5. Devuelve el nombre del departamento donde trabaja el empleado que tiene el nif 38382980M.

select departamento.nombre,nif from departamento,empleado where nif like '38382980M';

-- 6. Devuelve el nombre del departamento donde trabaja el empleado Pepe Ruiz Santana.

select departamento.nombre,empleado.nombre from departamento,empleado where empleado.nombre like 'pepe' and apellido1 like '%Ruiz' and apellido2 like 'Santana';

-- 7. Devuelve un listado con los datos de los empleados que trabajan en el departamento de I+D. Ordena el resultado alfabéticamente.

select *,departamento.nombre from empleado,departamento where departamento.nombre like 'I+D'order by empleado.nombre;

-- 8. Devuelve un listado con los datos de los empleados que trabajan en el departamento de Sistemas, Contabilidad o I+D. Ordena el resultado alfabéticamente.

select *,departamento.nombre from empleado,departamento where departamento.nombre like 'Sistemas' or departamento.nombre like 'Contabilidad' or departamento.nombre like 'I+D' order by empleado.nombre;

-- 9. Devuelve una lista con el nombre de los empleados que tienen los departamentos que no tienen un presupuesto entre 100000 y 200000 euros.

SELECT empleado.nombre FROM empleado,departamento WHERE NOT (presupuesto>100000 AND presupuesto<200000);

-- 10. Devuelve un listado con el nombre de los departamentos donde existe algún empleado cuyo segundo apellido sea NULL. Tenga en cuenta que no debe mostrar nombres de departamentos que estén repetidos.

select departamento.nombre from departamento,empleado where not empleado.apellido2 like 'null';

-- 11. Devuelve un listado con todos los empleados junto con los datos de los departamentos donde trabajan. Este listado también debe incluir los empleados que no tienen ningún departamento asociado.

select *,empleado.nombre from departamento,empleado where not departamento.nombre is null;

-- 12. Devuelve un listado donde sólo aparezcan aquellos empleados que no tienen ningún departamento asociado.

select concat(d.nombre,apellido1) from empleado left join departamento d on d.codigo = empleado.codigo_departamento where codigo_departamento is null;

-- 13. Devuelve un listado donde sólo aparezcan aquellos departamentos que no tienen ningún empleado asociado.

select departamento.nombre from departamento,empleado where empleado.nombre is null;

-- 14. Devuelve un listado con todos los empleados junto con los datos de los departamentos donde trabajan. El listado debe incluir los empleados que no tienen ningún departamento asociado y los departamentos que no tienen ningún empleado asociado. Ordene el listado alfabéticamente por el nombre del departamento.

select * ,empleado.nombre  from empleado, departamento where empleado.nombre is null order by departamento.nombre;

-- 15. Devuelve un listado con los empleados que no tienen ningún departamento asociado y los departamentos que no tienen ningún empleado asociado. Ordene el listado alfabéticamente por el nombre del departamento.