namespace futbol
{
    public partial class Form1 : Form
    {
       Form1[] arraysalas = new Form1[4];
        public Form1()
        {
            InitializeComponent();
        }

        private void equiposToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Equipos Formulario = new Equipos();
            Formulario.Show();
        }

        private void fugadoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void partidisYResultadosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PartidosyResultados Formulario = new PartidosyResultados();
            Formulario.ShowDialog();
        }

        private void clasificacionesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PartidosyResultados Formulario = new PartidosyResultados ();
            Formulario.ShowDialog();
        }

        private void ganadoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PartidosyResultados Formulario = new PartidosyResultados();
            Formulario.ShowDialog();
            ;
        }

        private void jugadoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            jugadores Formulario = new jugadores();
            Formulario.ShowDialog();
        }
    }
}