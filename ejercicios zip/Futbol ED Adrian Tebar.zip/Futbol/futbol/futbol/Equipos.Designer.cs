﻿namespace futbol
{
    partial class Equipos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Nombre_Equipo = new System.Windows.Forms.Label();
            this.Numero_Equipo = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // Nombre_Equipo
            // 
            this.Nombre_Equipo.AutoSize = true;
            this.Nombre_Equipo.Location = new System.Drawing.Point(192, 137);
            this.Nombre_Equipo.Name = "Nombre_Equipo";
            this.Nombre_Equipo.Size = new System.Drawing.Size(168, 25);
            this.Nombre_Equipo.TabIndex = 0;
            this.Nombre_Equipo.Text = "Nombre del Equipo";
            // 
            // Numero_Equipo
            // 
            this.Numero_Equipo.AutoSize = true;
            this.Numero_Equipo.Location = new System.Drawing.Point(172, 224);
            this.Numero_Equipo.Name = "Numero_Equipo";
            this.Numero_Equipo.Size = new System.Drawing.Size(188, 25);
            this.Numero_Equipo.TabIndex = 1;
            this.Numero_Equipo.Text = "Numero de Jugadores";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(376, 137);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(201, 27);
            this.textBox1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(376, 224);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(201, 25);
            this.textBox2.TabIndex = 3;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(622, 314);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(166, 85);
            this.button3.TabIndex = 13;
            this.button3.Text = "crear";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(622, 223);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(166, 85);
            this.button2.TabIndex = 12;
            this.button2.Text = "borrar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(622, 132);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(166, 85);
            this.button1.TabIndex = 11;
            this.button1.Text = "Consultar";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(622, 32);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(166, 85);
            this.button4.TabIndex = 14;
            this.button4.Text = "Modificar";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Valencia",
            "Barcelona",
            "Madrid ",
            "Betis"});
            this.comboBox1.Location = new System.Drawing.Point(216, 47);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(300, 33);
            this.comboBox1.TabIndex = 15;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Equipos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Numero_Equipo);
            this.Controls.Add(this.Nombre_Equipo);
            this.Name = "Equipos";
            this.Text = "Equipos";
            this.Load += new System.EventHandler(this.Equipos_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label Nombre_Equipo;
        private Label Numero_Equipo;
        private TextBox textBox1;
        private TextBox textBox2;
        private Button button3;
        private Button button2;
        private Button button1;
        private Button button4;
        private ComboBox comboBox1;
    }
}