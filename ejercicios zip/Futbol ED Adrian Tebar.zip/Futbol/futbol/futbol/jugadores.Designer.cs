﻿namespace futbol
{
    partial class jugadores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Nombre_jugadores = new System.Windows.Forms.Label();
            this.Apellidos_Jugadores = new System.Windows.Forms.Label();
            this.Gmail_jugadores = new System.Windows.Forms.Label();
            this.Telefono_Jugadores = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // Nombre_jugadores
            // 
            this.Nombre_jugadores.AutoSize = true;
            this.Nombre_jugadores.Location = new System.Drawing.Point(179, 71);
            this.Nombre_jugadores.Name = "Nombre_jugadores";
            this.Nombre_jugadores.Size = new System.Drawing.Size(78, 25);
            this.Nombre_jugadores.TabIndex = 0;
            this.Nombre_jugadores.Text = "Nombre";
            // 
            // Apellidos_Jugadores
            // 
            this.Apellidos_Jugadores.AutoSize = true;
            this.Apellidos_Jugadores.Location = new System.Drawing.Point(179, 139);
            this.Apellidos_Jugadores.Name = "Apellidos_Jugadores";
            this.Apellidos_Jugadores.Size = new System.Drawing.Size(86, 25);
            this.Apellidos_Jugadores.TabIndex = 1;
            this.Apellidos_Jugadores.Text = "Apellidos";
            // 
            // Gmail_jugadores
            // 
            this.Gmail_jugadores.AutoSize = true;
            this.Gmail_jugadores.Location = new System.Drawing.Point(179, 212);
            this.Gmail_jugadores.Name = "Gmail_jugadores";
            this.Gmail_jugadores.Size = new System.Drawing.Size(57, 25);
            this.Gmail_jugadores.TabIndex = 2;
            this.Gmail_jugadores.Text = "Gmail";
            // 
            // Telefono_Jugadores
            // 
            this.Telefono_Jugadores.AutoSize = true;
            this.Telefono_Jugadores.Location = new System.Drawing.Point(179, 280);
            this.Telefono_Jugadores.Name = "Telefono_Jugadores";
            this.Telefono_Jugadores.Size = new System.Drawing.Size(79, 25);
            this.Telefono_Jugadores.TabIndex = 3;
            this.Telefono_Jugadores.Text = "Telefono";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(287, 68);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(187, 27);
            this.textBox1.TabIndex = 4;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(287, 137);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(187, 27);
            this.textBox2.TabIndex = 5;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(287, 212);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(187, 27);
            this.textBox3.TabIndex = 6;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(287, 280);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(187, 27);
            this.textBox4.TabIndex = 7;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(542, 212);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(166, 85);
            this.button2.TabIndex = 9;
            this.button2.Text = "borrar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(542, 311);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(166, 85);
            this.button3.TabIndex = 10;
            this.button3.Text = "crear";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(542, 10);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(166, 85);
            this.button4.TabIndex = 16;
            this.button4.Text = "Modificar";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(542, 110);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(166, 85);
            this.button1.TabIndex = 15;
            this.button1.Text = "Consultar";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Lucas aaa",
            "Mariano aaa",
            "pedro aaa",
            "Gavi aaa",
            "Marcos aaa"});
            this.comboBox1.Location = new System.Drawing.Point(65, 21);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(340, 33);
            this.comboBox1.TabIndex = 17;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // jugadores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Telefono_Jugadores);
            this.Controls.Add(this.Gmail_jugadores);
            this.Controls.Add(this.Apellidos_Jugadores);
            this.Controls.Add(this.Nombre_jugadores);
            this.Name = "jugadores";
            this.Text = "jugadores";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label Nombre_jugadores;
        private Label Apellidos_Jugadores;
        private Label Gmail_jugadores;
        private Label Telefono_Jugadores;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button1;
        private ComboBox comboBox1;
    }
}