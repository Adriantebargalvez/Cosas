﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace futbol
{
    public partial class Equipos : Form
    {
        Equipos[] arrayequipo = new Equipos[11];
        public Equipos()
        {
            InitializeComponent();
        }

        private void Equipos_Load(object sender, EventArgs e)
        {
            string nombreArchivo = "Equipo.txt";

            FileStream fs = File.Create(nombreArchivo);
            arrayequipo[0] = new Equipos();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            RemoveOwnedForm(arrayequipo[0]);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox1.SelectedIndex == 0)
            {
                textBox1.Text = "Valencia";
                textBox2.Text = "11";
            }
            if (comboBox1.SelectedIndex == 1)
            {
                textBox1.Text = "Barcelona";
                textBox2.Text = "11";
            }
            if (comboBox1.SelectedIndex == 2)
            {
                textBox1.Text = "Madrid";
                textBox2.Text = "11";
            }
            if (comboBox1.SelectedIndex == 3)
            {
                textBox1.Text = "Betis";
                textBox2.Text = "11";
            }
        }
    }
}
