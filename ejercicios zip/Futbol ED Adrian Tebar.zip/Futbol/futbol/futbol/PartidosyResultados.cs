﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace futbol
{
    public partial class PartidosyResultados : Form
    {
        public PartidosyResultados()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void PartidosyResultados_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (numericUpDown1.Value == numericUpDown2.Value)
            {
                MessageBox.Show("EMPATE");
            }
            else
            {

                if (numericUpDown1.Value < numericUpDown2.Value)
                {
                    MessageBox.Show("Ha ganado el equipo 2");
                }
                else
                {
                    MessageBox.Show("Ha ganado el equipo 1");
                }

            }

           
            }
            
            }
            }
        
    

