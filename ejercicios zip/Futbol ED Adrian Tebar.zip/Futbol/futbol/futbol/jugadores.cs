﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace futbol
{
    public partial class jugadores : Form
    {
        jugadores[] arrayjugadores = new jugadores[11];
        public jugadores()
        {
            InitializeComponent();
        }
        
        private void button3_Click(object sender, EventArgs e)
        {
            string nombreArchivo = "jugador.txt";

            FileStream fs = File.Create(nombreArchivo);
            arrayjugadores[0] = new jugadores();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            RemoveOwnedForm(arrayjugadores[0]);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                textBox1.Text = "Lucas";
                textBox2.Text = "aaa";
                textBox3.Text = "Lucas@gmail.com";
                textBox4.Text = "24242424";
            }
            if (comboBox1.SelectedIndex == 1)
            {
                textBox1.Text = "Mariano ";
                textBox2.Text = "aaa";
                textBox3.Text = "Mariano@gmail.com";
                textBox4.Text = "24242424";
            }
            if (comboBox1.SelectedIndex == 2)
            {
                textBox1.Text = "pedro";
                textBox2.Text = "aaa";
                textBox3.Text = "Pedro@gmail.com";
                textBox4.Text = "24242674";
            }
            if (comboBox1.SelectedIndex == 3)
            {
                textBox1.Text = "Gavi";
                textBox2.Text = "11";
                textBox3.Text = "gavi@gmail.com";
                textBox4.Text = "24243424";


            }
            if (comboBox1.SelectedIndex == 3)
            {
                textBox1.Text = " Marcos";
                textBox2.Text = "aaa";
                textBox3.Text = "Marcos@gmail.com";
                textBox4.Text = "24244424";


            }
        }
    }
}
