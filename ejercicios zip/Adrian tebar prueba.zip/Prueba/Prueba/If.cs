﻿namespace Prueba
{
    internal class If
    {
    }
}