﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;

namespace Prueba
{

    public partial class Form2 : Form
    {
        private DateTime femp;

        private void salario_TextChanged()
        {
            salario.Text = "Salario";
            if (comboBox1.SelectedIndex == 0)
            {
                salario.Text = "1000";

            }

            if (comboBox1.SelectedIndex == 1)
            {
                salario.Text = "1750";

            }


            if (comboBox1.SelectedIndex == 2)
            {
                salario.Text = "2500";

            }
        }
        public Form2()
        {
            InitializeComponent();


        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            salario_TextChanged();
        }




        private void Administracion_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown2.Enabled = false;
            if (Administracion.Checked)
            {
                numericUpDown2.Enabled = true;
            }
        }

        private void Mantenimiento_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown1.Enabled = false;
            if (Mantenimiento.Checked)
            {
                numericUpDown1.Enabled = true;
            }
        }

        private void Comerciales_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown3.Enabled = false;
            if (Comerciales.Checked)
            {
                numericUpDown3.Enabled = true;
            }
        }

        private void Produccion_CheckedChanged(object sender, EventArgs e)
        {
            numericUpDown4.Enabled = false;
            if (Produccion.Checked)
            {
                numericUpDown4.Enabled = true;
            }
        }

        private void Calculare_Click(object sender, EventArgs e)
        {
            
            int ageInYears=0;
            // Get the age in years
            if (dateTimePicker2.Value.Year > dateTimePicker1.Value.Year) {
                ageInYears=  DateTime.Today.Year - (dateTimePicker1.Value.Year);
            }
            MessageBox.Show(ageInYears.ToString());

        }

        

        private void Calculara_Click_1(object sender, EventArgs e)
        {
            
           
     MessageBox.Show("La antigüedad del empleado es: " + cantiguedad() + " meses");
            
        }
        public int cantiguedad()
        {
            // en meses
            TimeSpan ant = DateTime.Today.Subtract(dateTimePicker2.Value);
            int dias = (int)ant.TotalDays;
            return dias / 30;
        }

    } 
}

    

