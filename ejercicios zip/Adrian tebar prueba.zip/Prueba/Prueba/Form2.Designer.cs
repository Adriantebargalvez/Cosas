﻿namespace Prueba
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ruta = new System.Windows.Forms.Label();
            this.datos = new System.Windows.Forms.Label();
            this.nombre = new System.Windows.Forms.Label();
            this.apellidos = new System.Windows.Forms.Label();
            this.calculos = new System.Windows.Forms.Label();
            this.fechad = new System.Windows.Forms.Label();
            this.datosem = new System.Windows.Forms.Label();
            this.salario = new System.Windows.Forms.Label();
            this.fecha = new System.Windows.Forms.Label();
            this.personas = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.Administracion = new System.Windows.Forms.CheckBox();
            this.Mantenimiento = new System.Windows.Forms.CheckBox();
            this.Comerciales = new System.Windows.Forms.CheckBox();
            this.Produccion = new System.Windows.Forms.CheckBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown4 = new System.Windows.Forms.NumericUpDown();
            this.Abrir = new System.Windows.Forms.Button();
            this.Guardar = new System.Windows.Forms.Button();
            this.Calculare = new System.Windows.Forms.Button();
            this.Calculara = new System.Windows.Forms.Button();
            this.Alta = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).BeginInit();
            this.SuspendLayout();
            // 
            // ruta
            // 
            this.ruta.AutoSize = true;
            this.ruta.Location = new System.Drawing.Point(25, 30);
            this.ruta.Name = "ruta";
            this.ruta.Size = new System.Drawing.Size(44, 20);
            this.ruta.TabIndex = 0;
            this.ruta.Text = "Ruta";
            // 
            // datos
            // 
            this.datos.AutoSize = true;
            this.datos.Location = new System.Drawing.Point(25, 85);
            this.datos.Name = "datos";
            this.datos.Size = new System.Drawing.Size(135, 20);
            this.datos.TabIndex = 1;
            this.datos.Text = "Datos Personales";
            // 
            // nombre
            // 
            this.nombre.AutoSize = true;
            this.nombre.Location = new System.Drawing.Point(25, 139);
            this.nombre.Name = "nombre";
            this.nombre.Size = new System.Drawing.Size(65, 20);
            this.nombre.TabIndex = 2;
            this.nombre.Text = "Nombre";
            // 
            // apellidos
            // 
            this.apellidos.AutoSize = true;
            this.apellidos.Location = new System.Drawing.Point(25, 186);
            this.apellidos.Name = "apellidos";
            this.apellidos.Size = new System.Drawing.Size(73, 20);
            this.apellidos.TabIndex = 3;
            this.apellidos.Text = "Apellidos";
            // 
            // calculos
            // 
            this.calculos.AutoSize = true;
            this.calculos.Location = new System.Drawing.Point(537, 110);
            this.calculos.Name = "calculos";
            this.calculos.Size = new System.Drawing.Size(69, 20);
            this.calculos.TabIndex = 4;
            this.calculos.Text = "Calculos";
            // 
            // fechad
            // 
            this.fechad.AutoSize = true;
            this.fechad.Location = new System.Drawing.Point(25, 225);
            this.fechad.Name = "fechad";
            this.fechad.Size = new System.Drawing.Size(54, 20);
            this.fechad.TabIndex = 5;
            this.fechad.Text = "Fecha";
            // 
            // datosem
            // 
            this.datosem.AutoSize = true;
            this.datosem.Location = new System.Drawing.Point(25, 283);
            this.datosem.Name = "datosem";
            this.datosem.Size = new System.Drawing.Size(120, 20);
            this.datosem.TabIndex = 6;
            this.datosem.Text = "Datos Empresa";
            // 
            // salario
            // 
            this.salario.AutoSize = true;
            this.salario.Location = new System.Drawing.Point(25, 371);
            this.salario.Name = "salario";
            this.salario.Size = new System.Drawing.Size(58, 20);
            this.salario.TabIndex = 7;
            this.salario.Text = "Salario";
            // 
            // fecha
            // 
            this.fecha.AutoSize = true;
            this.fecha.Location = new System.Drawing.Point(25, 328);
            this.fecha.Name = "fecha";
            this.fecha.Size = new System.Drawing.Size(54, 20);
            this.fecha.TabIndex = 8;
            this.fecha.Text = "Fecha";
            // 
            // personas
            // 
            this.personas.AutoSize = true;
            this.personas.Location = new System.Drawing.Point(25, 408);
            this.personas.Name = "personas";
            this.personas.Size = new System.Drawing.Size(89, 20);
            this.personas.TabIndex = 9;
            this.personas.Text = "Personas a";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(114, 27);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(131, 23);
            this.textBox1.TabIndex = 10;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(155, 139);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(131, 23);
            this.textBox2.TabIndex = 11;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(155, 183);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(131, 23);
            this.textBox3.TabIndex = 12;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(114, 225);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(217, 26);
            this.dateTimePicker1.TabIndex = 13;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(97, 328);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(217, 26);
            this.dateTimePicker2.TabIndex = 14;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Empleado ",
            "Jefe de departamento",
            "Director"});
            this.comboBox1.Location = new System.Drawing.Point(97, 368);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(254, 28);
            this.comboBox1.TabIndex = 15;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Administracion
            // 
            this.Administracion.AutoSize = true;
            this.Administracion.Location = new System.Drawing.Point(132, 490);
            this.Administracion.Name = "Administracion";
            this.Administracion.Size = new System.Drawing.Size(139, 24);
            this.Administracion.TabIndex = 16;
            this.Administracion.Text = "Administracion";
            this.Administracion.UseVisualStyleBackColor = true;
            this.Administracion.CheckedChanged += new System.EventHandler(this.Administracion_CheckedChanged);
            // 
            // Mantenimiento
            // 
            this.Mantenimiento.AutoSize = true;
            this.Mantenimiento.Location = new System.Drawing.Point(132, 541);
            this.Mantenimiento.Name = "Mantenimiento";
            this.Mantenimiento.Size = new System.Drawing.Size(140, 24);
            this.Mantenimiento.TabIndex = 17;
            this.Mantenimiento.Text = "Mantenimiento";
            this.Mantenimiento.UseVisualStyleBackColor = true;
            this.Mantenimiento.CheckedChanged += new System.EventHandler(this.Mantenimiento_CheckedChanged);
            // 
            // Comerciales
            // 
            this.Comerciales.AutoSize = true;
            this.Comerciales.Location = new System.Drawing.Point(132, 589);
            this.Comerciales.Name = "Comerciales";
            this.Comerciales.Size = new System.Drawing.Size(122, 24);
            this.Comerciales.TabIndex = 18;
            this.Comerciales.Text = "Comerciales";
            this.Comerciales.UseVisualStyleBackColor = true;
            this.Comerciales.CheckedChanged += new System.EventHandler(this.Comerciales_CheckedChanged);
            // 
            // Produccion
            // 
            this.Produccion.AutoSize = true;
            this.Produccion.Location = new System.Drawing.Point(132, 638);
            this.Produccion.Name = "Produccion";
            this.Produccion.Size = new System.Drawing.Size(114, 24);
            this.Produccion.TabIndex = 19;
            this.Produccion.Text = "Produccion";
            this.Produccion.UseVisualStyleBackColor = true;
            this.Produccion.CheckedChanged += new System.EventHandler(this.Produccion_CheckedChanged);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(371, 541);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(58, 26);
            this.numericUpDown1.TabIndex = 20;
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(371, 490);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(58, 26);
            this.numericUpDown2.TabIndex = 21;
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Location = new System.Drawing.Point(371, 589);
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(58, 26);
            this.numericUpDown3.TabIndex = 22;
            // 
            // numericUpDown4
            // 
            this.numericUpDown4.Location = new System.Drawing.Point(371, 638);
            this.numericUpDown4.Name = "numericUpDown4";
            this.numericUpDown4.Size = new System.Drawing.Size(58, 26);
            this.numericUpDown4.TabIndex = 23;
            // 
            // Abrir
            // 
            this.Abrir.FlatAppearance.BorderSize = 0;
            this.Abrir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Abrir.Location = new System.Drawing.Point(450, 12);
            this.Abrir.Name = "Abrir";
            this.Abrir.Size = new System.Drawing.Size(114, 63);
            this.Abrir.TabIndex = 24;
            this.Abrir.Text = "Abrir Archivo";
            this.Abrir.UseVisualStyleBackColor = true;
            // 
            // Guardar
            // 
            this.Guardar.Location = new System.Drawing.Point(615, 12);
            this.Guardar.Name = "Guardar";
            this.Guardar.Size = new System.Drawing.Size(114, 63);
            this.Guardar.TabIndex = 25;
            this.Guardar.Text = "Guardar";
            this.Guardar.UseVisualStyleBackColor = true;
            // 
            // Calculare
            // 
            this.Calculare.Location = new System.Drawing.Point(518, 165);
            this.Calculare.Name = "Calculare";
            this.Calculare.Size = new System.Drawing.Size(114, 63);
            this.Calculare.TabIndex = 26;
            this.Calculare.Text = "Calcular Edad";
            this.Calculare.UseVisualStyleBackColor = true;
            this.Calculare.Click += new System.EventHandler(this.Calculare_Click);
            // 
            // Calculara
            // 
            this.Calculara.Location = new System.Drawing.Point(518, 249);
            this.Calculara.Name = "Calculara";
            this.Calculara.Size = new System.Drawing.Size(114, 63);
            this.Calculara.TabIndex = 27;
            this.Calculara.Text = "Calcular Antiguedad";
            this.Calculara.UseVisualStyleBackColor = true;
            this.Calculara.Click += new System.EventHandler(this.Calculara_Click_1);
            // 
            // Alta
            // 
            this.Alta.Location = new System.Drawing.Point(0, 601);
            this.Alta.Name = "Alta";
            this.Alta.Size = new System.Drawing.Size(114, 63);
            this.Alta.TabIndex = 28;
            this.Alta.Text = "Alta";
            this.Alta.UseVisualStyleBackColor = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 715);
            this.Controls.Add(this.Alta);
            this.Controls.Add(this.Calculara);
            this.Controls.Add(this.Calculare);
            this.Controls.Add(this.Guardar);
            this.Controls.Add(this.Abrir);
            this.Controls.Add(this.numericUpDown4);
            this.Controls.Add(this.numericUpDown3);
            this.Controls.Add(this.numericUpDown2);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.Produccion);
            this.Controls.Add(this.Comerciales);
            this.Controls.Add(this.Mantenimiento);
            this.Controls.Add(this.Administracion);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.personas);
            this.Controls.Add(this.fecha);
            this.Controls.Add(this.salario);
            this.Controls.Add(this.datosem);
            this.Controls.Add(this.fechad);
            this.Controls.Add(this.calculos);
            this.Controls.Add(this.apellidos);
            this.Controls.Add(this.nombre);
            this.Controls.Add(this.datos);
            this.Controls.Add(this.ruta);
            this.Name = "Form2";
            this.Text = "Datos";
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ruta;
        private System.Windows.Forms.Label datos;
        private System.Windows.Forms.Label nombre;
        private System.Windows.Forms.Label apellidos;
        private System.Windows.Forms.Label calculos;
        private System.Windows.Forms.Label fechad;
        private System.Windows.Forms.Label datosem;
        private System.Windows.Forms.Label salario;
        private System.Windows.Forms.Label fecha;
        private System.Windows.Forms.Label personas;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.CheckBox Administracion;
        private System.Windows.Forms.CheckBox Mantenimiento;
        private System.Windows.Forms.CheckBox Comerciales;
        private System.Windows.Forms.CheckBox Produccion;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.NumericUpDown numericUpDown4;
        private System.Windows.Forms.Button Abrir;
        private System.Windows.Forms.Button Guardar;
        private System.Windows.Forms.Button Calculare;
        private System.Windows.Forms.Button Calculara;
        private System.Windows.Forms.Button Alta;
    }
}