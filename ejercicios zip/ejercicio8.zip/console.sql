drop database if exists uni;
create database uni;
use uni;

create table departamento
(
    id     int(10),
    nombre Varchar(50)
);
create table grado(
  id INT(10),
  nombre varchar(100)
);
create table profesor(
    id_profesor Int(10),
    id_departamento int (10)
);
create table persona(
  id int(10),
  nif varchar(9),
    nombre varchar(50),
    apellido1 varchar(50),
    apellido2 varchar (50),
    ciudad varchar(25),
    direccion varchar(25),
    telefono varchar(9),
    fecha_nacimiento DATE,
    sexo ENUM('H','M'),
    tipo enum('profesor','alumno')

);
create table asignatura(
  id int(10),
  nombre varchar(100),
  creditos FLOAT,
  tipo enum('basica' ,'optativa', 'obligatoria'),
 curso TINYINT(3),
 cuatrimestre TINYINT(3),
id_profesor int (10),
id_grado int (10)
);
create table curso_escolar(
    id int(10),
    anyo_inicio YEAR(4),
    anyo_fin YEAR(4)

);
create table alumno_se_matricula_asignatura(
    id_alumno int(10),
    id_asignatura int (10),
    id_curso_escolar int (10)
);

