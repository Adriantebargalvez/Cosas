-- 1. Devuelve el número total de alumnas que hay.
SELECT count(id) AS 'Numero alumnas'
FROM persona
where sexo = 'M'and tipo='alumno';

-- 2. Calcula cuántos alumnos nacieron en 1999.
SELECT *FROM persona WHERE year(fecha_nacimiento) = '1999';
-- 3. Calcula cuántos profesores hay en cada departamento. El resultado sólo debe mostrar dos columnas, una con el nombre del departamento y otra con el número de profesores que hay en ese departamento. El resultado sólo debe incluir los departamentos que tienen profesores asociados y deberá estar ordenado de mayor a menor por el número de profesores.
SELECT departamento.nombre, COUNT(profesor.id_departamento) "Numero de Profesores"FROM departamento LEFT JOIN profesor ON departamento.id = profesor.id_departamento WHERE profesor.id_departamento IS NOT NULL GROUP BY profesor.id_departamento ORDER BY 2 DESC;
-- 4. Devuelve un listado con todos los departamentos y el número de  profesores que hay en cada uno de ellos. Tenga en cuenta que pueden existir departamentos que no tienen profesores asociados. Estos departamentos también tienen que aparecer en el listado.
SELECT nombre "Departamento",COUNT(id_departamento) "Cantidad Profesores"FROM departamento LEFT JOIN profesor p ON id = p.id_departamento group by p.id_departamento ORDER BY 2 DESC;
-- 5. Devuelve un listado con el nombre de todos los grados existentes en la base de datos y el número de asignaturas que tiene cada uno. Tenga en cuenta que pueden existir grados que no tienen asignaturas asociadas.Estos grados también tienen que aparecer en el listado. El resultado deberá estar ordenado de mayor a menor por el número de asignaturas.
SELECT a.nombre, count(a.id) 'Cantidad de asignaturas'FROM grado JOIN asignatura a ON a.id = grado.id group by nombre ORDER BY COUNT(a.id);
-- 6. Devuelve un listado con el nombre de todos los grados existentes en la base de datos y el número de asignaturas que tiene cada uno, de los grados que tengan más de 40 asignaturas asociadas.
SELECT g.nombre, COUNT(a.id_grado) AS numasignatura from grado g
left join asignatura a on g.id = a.id_grado group by g.nombre
having numasignatura>40 order by  numasignatura DESC ;
-- 7. Devuelve un listado que muestre el nombre de los grados y la suma del número total de créditos que hay para cada tipo de asignatura. El resultado debe tener tres columnas: nombre del grado, tipo de asignatura y la suma de los créditos de todas las asignaturas que hay de ese tipo. Ordene el resultado de mayor a menor por el número total de crédidos.

-- 8. Devuelve un listado que muestre cuántos alumnos se han matriculado de alguna asignatura en cada uno de los cursos escolares. El resultado deberá mostrar dos columnas, una columna con el año de inicio del curso escolar y otra con el número de alumnos matriculados.
SELECT anyo_inicio "curso escolar",alumno_se_matricula_asignatura.id_alumno,
COUNT(alumno_se_matricula_asignatura.id_alumno)FROM curso_escolar celeft JOIN alumno_se_matricula_asignatura ON  id = alumno_se_matricula_asignatura.id_curso_escolar GROUP BY anyo_inicio ORDER BY COUNT(alumno_se_matricula_asignatura.id_alumno);
-- 9. Devuelve un listado con el número de asignaturas que imparte cada profesor. El listado debe tener en cuenta aquellos profesores que no imparten ninguna asignatura. El resultado mostrará cinco columnas: id, nombre, primer apellido, segundo apellido y número de asignaturas. El resultado estará ordenado de mayor a menor por el número de asignaturas.
SELECT id "ID Profesor",nombre "Nombre Profesor",id "numero asignatura",COUNT(id)FROM asignatura aleft JOIN profesor p ON  p.id_profesor = p.id_profesor GROUP BY p.id_profesor ORDER BY COUNT(id) ;
-- 10. Devuelve el % de alumnas del total de alumnos que hay.

