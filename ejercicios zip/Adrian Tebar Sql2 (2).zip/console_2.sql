drop database if exists empresas;
create database empresas;
use empresas;

create table empleado
(
    codigo int primary key ,
    nombre varchar(100),
    apellido varchar (100),
    sueldo double,
    nombre_dpt varchar(100),
    ciudad varchar(100),
    num int,
    FOREIGN KEY (nombre_dpt,ciudad) references departamento(nombre,ciudad)

);
insert into empleado values
( 1,	'Mada',	'Puig'	,100000.0	,'DIR'	,'Gerona' 	,1),
(2,	'Pedro',	'Mas',	90000.0	,'DIR','Barcelona', 4),
(3,	'Ana',	'Ros',	70000.0	,'DIS'	,'Lerlda' ,3),
(4,	'Jorge',	'Roca'	,70000.0,	'DIS'	,'Barcelona' ,4),
(5,	'Laura',	'Ton',	30000.0,	'PROG'	,'Tarragona' ,3),
(6,	'Roger',	'S alt'	,40000.0	,NULL,NULL,4),
(7,	'Suplo',	'Grau', 30000.0	,'PROG'	,'Tarragona',NULL);

create table departamento
(
nombre varchar(10),
ciudad varchar(10),
telefono int,
Primary key (nombre,ciudad)
);
insert into departamento values
('DIR', 'Barcelona' ,934226070),
('DIR', 'Gerona', 972238970),
('DIS', 'Lerida', 973233040 ),
('DIS' ,'Barcelona' ,932248523 ),
( 'PROG' ,'Tarragona' ,977333852 ),
 ('PROG', 'Gerona' ,972235091 );

create table cliente(
  codigo int primary key ,
  nombre varchar(10),
  nif varchar(10),
  dieccion varchar(10),
  ciudad varchar(10),
  telefono int

);
insert into cliente values
(10, 'ECIGSA' ,'38.567893-C', 'Aragon 11', 'Barcelona' ,NULL),
(20, 'CME' ,'38123898-E' ,'Valencia 22', 'Gerona' ,972235721 ),
( 30, 'ACME', '36432127-A' , 'Mallorca 33', 'Lerida' ,973234567),
( 40, 'IGM','38782345-B' ,'Rossellon 4' ,'Tarragona' ,977337143 );

create table proyectos (
codigo int primary key ,
nombre varchar(10),
precio int,
fecha_ini int,
fecha_fin int,
fecha_pre_fin int,
codigo_cliente int,
FOREIGN KEY (codigo_cliente) REFERENCES cliente(codigo)

);

insert into proyectos values
(1 ,'GESCOM', 1000000.0 ,1-1-98 ,1-1-99 ,NULL ,10),
( 2 ,'PESCI' ,2000000.0 ,1-10-96, 31-3-98 ,1-5-98 ,10),
( 3 ,'SALSA', 1000000.0, 10-2-98 ,1-2-99 ,NULL ,20),
( 4 ,'T1NELL' ,4000000.0 ,1-1-97 ,1-12-99 ,NULL ,30 );
