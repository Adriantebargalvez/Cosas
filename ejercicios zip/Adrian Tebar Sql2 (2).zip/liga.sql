drop database if exists liga;
create database liga;
use liga;
create table jugadores
(
Id_jugador int primary key ,
Nombre varchar(20),
Apellido varchar(20),
Puesto varchar(10),
Id_capitan int,
Fecha_alta varchar(10),
Salario int,
Num_equipo int,
altura int
);
insert into jugadores values
(1, 'Juan Carlos', 'Navarro', 'Escolta', 1, '10/01/2010' ,130.000,1,null),
(2, 'Felipe', 'Reyes', 'Pivot',2 ,'20/02/2009' ,120.000 ,2,2.04),
(3, 'Victor', 'Claver', 'Alero' ,3 ,'08/03/2009' ,90.000 ,3 ,2.08),
(4, 'Rafa', 'Martinez', 'Escolta' ,4 ,'11/11/2010' ,51.000 ,3 ,1.91),
(5, 'Fernando', 'San Emeterio', 'Alero' ,6 ,'22/09/2008' ,60.000 ,4 ,1.99),
(6, 'Mirza', 'Teletovic', 'Pivot' ,6 ,'13/05/2010' ,70.000 ,4 ,2.06),
(7, 'Sergio', 'Llull', 'Escolta' ,2 ,'29/10/2011' ,100.000 ,2 ,1.90),
(8, 'Victor', 'Sada', 'Base' ,1 ,'01/01/2012' ,80.000 ,1 ,1.92),
(9, 'Carlos', 'Suarez', 'Alero' ,2 ,'19/02/2011' ,60.000 ,2 ,2.03),
(10, 'Xavi', 'Rey', 'Pivot' ,14 ,'12/10/2008' ,95.000 ,5 ,2.09),
(11, 'Carlos', 'Cabezas', 'Base' ,13 ,'21/01/2012' ,105.000 ,6 ,1.86),
(12, 'Pablo', 'Aguilar', 'Alero' ,13 ,'14/06/2011' ,47.000 ,6 ,2.03),
(13, 'Rafa', 'Hettsheimeir', 'Pivot', 13 ,'15/04/2008',53.000 ,6 ,2.08),
(14, 'Sitapha', 'Savane', 'Pivot', 14 ,'27/07/2011' ,60.000 ,5 ,2.01);

create table equipo
(
Id_equipo int primary key ,
Nombre_equipo varchar(20),
Ciudad varchar(10),
Web varchar(40),
Puntos int

);
insert into equipo values
(1, 'Real Barcelona', 'Barcelona', 'http://www.fcbarcelona.com' ,10),
(2, 'Real Madrid', 'Madrid', 'http://www.realmadrid.com' ,9),
(3, 'P.E. Valencia', 'Valencia', 'http://www.valenciabasket.com' ,11),
(4, 'Caja Laboral', 'Vitoria', 'http://www.baskonia.com' ,22),
(5, 'Gran Canaria', 'Las Palmas', 'http://www.acb.com' ,14),
(6, 'CAI Zaragoza', 'Zaragoza', 'http://basketzaragoza.net', 23);
create table partidos
(
Elocal int,
Evisitante int,
Resultado int,
Fecha int,
arbitro int,
Primary Key (Elocal,Evisitante)
);
insert into partidos values
(1, 2, 100-100, 10/10/2011, 4),
(2, 3, 90-91, 17/11/2011, 5),
(3, 4, 88-77, 23/11/2011, 6),
(1, 6, 66-78, 30/11/2011, 6),
(2, 4, 90-90, 12/01/2012, 7),
(4, 5, 79-83, 19/01/2012, 3),
(3, 6, 91-88, 22/02/2012 ,3),
(5, 4, 90-66, 27/04/2012, 2),
(6, 5, 110-70, 30/05/2012 ,1);