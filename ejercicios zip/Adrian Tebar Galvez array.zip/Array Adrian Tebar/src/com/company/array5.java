package com.company;

public class array5 {
    public class Contacto {
        private String nombre;
        private String apellidos;
        private String telefono;

        public Contacto(String nombre, String apellidos, String telefono) {
            this.nombre = nombre;
            this.apellidos = apellidos;
            this.telefono = telefono;
        }


    }
}
