drop database if exists empresas;
create database empresas;
use empresas;

create table empleado
(
    codigo varchar(100)primary key ,
    nombre varchar(100),
    apellido varchar (100),
    sueldo int,
    num int,
    numbre_dpt varchar(100),
    ciudad varchar(100)

);
insert into empleado values
( 1,	'Mada',	'Puig'	,100000.0	,'DIR'	,'Gerona' 	,1),
(2,	'Pedro',	'Mas',	90000.0	,'DIR','Barcelona', 4),
(3,	'Ana',	'Ros',	70000.0	,'DIS'	,'Lerlda' ,3),
(4,	'Jorge',	'Roca'	,70000.0,	'DIS'	,'Barcelona' ,4),
(5,	'Laura',	'Ton',	30000.0,	'PROG'	,'Tarragona' ,3),
(6,	'Roger',	'S alt'	,40000.0	,NULL,NULL,4),
(7,	'Suplo',	'Grau', 30000.0	,'PROG'	,'Tarragona',NULL);

create table departamento
(
nombre varchar(10),
ciudad varchar(10),
telefono int
);
insert into departamento values
('DIR', 'Barcelona' ,93.422,60.70),
('DIR', 'Gerona', 972.23,89.70),
('DIS', 'Lerida', 973.2330,40 ),
('DIS' ,'Barcelona' ,93.224,85.23 ),
( 'PROG' ,'Tarragona' ,977.33,38.52 ),
 ('PROG', 'Gerona' ,972.23,50.91 );

create table cliente(
  codigo int,
  nombre varchar(10),
  nif varchar(10),
  dieccion varchar(10),
  ciudad varchar(10),
  telefono int

);
insert into cliente values
(10, 'ECIGSA' ,38.567,893-'C', 'Aragon', 11, 'Barcelona' ,NULL),
(20, 'CME' , 'Valencia' ,22, 'Gerona' ,972.23,57.21 ),
( 30, 'ACME' , 'Mallorca', 33, 'Lerida' ,973.23,45.67),
( 40, 'IGM', 'Rossellon' ,44 ,'Tarragona' ,977.33,71.43 );

create table proyectos (
codigo int,
nombre varchar(10),
precio int,
fecha_ini int,
fecha_fin int,
fecha_pre_fin int,
codigo_cliente int

);

insert into proyectos values
(1 ,'GESCOM', 1000000.0 ,1-1-98 ,1-1-99 ,NULL ,10),
( 2 ,'PESCI' ,2000000.0 ,1-10-96, 31-3-98 ,1-5-98 ,10),
( 3 ,'SALSA', 1000000.0, 10-2-98 ,1-2-99 ,NULL ,20),
( 4 ,'T1NELL' ,4000000.0 ,1-1-97 ,1-12-99 ,NULL ,30 );