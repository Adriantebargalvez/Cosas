package com.company;
import java.util.*;

import static java.lang.Math.*;

public class Main {
    static Scanner sc = new Scanner(System.in);
    static List<String> lista = new ArrayList<String>();
    static String[] array = new String[5];
  static   String[] introducircolo = new String[5];
  static   String[] simbolos = new String[5];
  static   boolean ganar = false;
   static int intentos = 0;
    public static void main(String[] args) {


        do {
//Hacemos las variables y los arrays y la lista




            iniciar_colores();
            //Hacemos un random de la lista
            for (int i = 0; i < 5; i++) {

                double numeroRandom = Math.random()*6;
                int aleatorio=(int)numeroRandom;
                array[i] = lista.get(aleatorio);
                lista.remove(aleatorio);
            }
            System.out.println(Arrays.toString(array));
            //Preguntamos los colores que cree que es
            introdu();
            //Segun si coincide pones * sino nada y si esta pero no en el puesto /
            simbolo();
            //Ganar y perder
           ganyper();
        }while(intentos<5 && !ganar);




    }

    private static void ganyper() {
        if (Arrays.equals(array, introducircolo)) {
            ganar = true;
            System.out.println("Felicidades has ganado");
        } else{
            intentos++;
        }
        if (intentos == 5) {
            System.out.println("Oh, lo siento has perdido");
        }
        //Si intentos es menor que 5 y aun no a ganado sigue
    }

    private static void simbolo() {
        for (int i = 0; i < 5; i++) {
            if (introducircolo[i].equals(array[i])) {
                simbolos[i] = "*";
            } else if (Arrays.asList(array).contains(introducircolo[i])) {
                simbolos[i] = "/";
            } else {
                simbolos[i] = " ";
            }

        }
        System.out.println(Arrays.toString(simbolos));
    }

    private static void introdu() {
        System.out.println("Dime 5 colores y haber si lo adivinas");
//Introducir color
        for (int i = 0; i < 5; i++) {
            introducircolo[i] = sc.next();

        }
    }

    private static void Crear_Solucion() {

    }

    private static void iniciar_colores() {

        lista.add("Blanco");
        lista.add("Amarillo");
        lista.add("Naranja");
        lista.add("Rosa");
        lista.add("Rojo");
        lista.add("Verde");
        lista.add("Azul");
        lista.add("Negro");
    }
}


