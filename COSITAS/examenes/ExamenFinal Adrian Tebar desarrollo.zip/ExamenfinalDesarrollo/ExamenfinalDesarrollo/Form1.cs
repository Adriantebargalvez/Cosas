﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.LinkLabel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ExamenfinalDesarrollo
{
    public partial class Form1 : Form
    {
        //hacemos una variable precio para usarla en tudo el programa
        int precio = 0;
        int suma = 0;
        public Form1()
        {
            InitializeComponent();
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        //creamos una variable bebidas y hacemos un switch en el que nos muestre los diferentes precios
        {
            string Bebidas = comboBox1.SelectedItem.ToString();
            switch (Bebidas)
            {
                case "Fanta":
                    //Esto es para que coloque la imagen segun la opcion que marquemos
                    pictureBox1.Image = Properties.Resources.fanta;
                    
                   
                    break;
                case "cerveza":
                    pictureBox1.Image = Properties.Resources.cerve;
                    
                    
                    break;
                case "cocacola":
                    pictureBox1.Image = Properties.Resources.coca;
                    
                    
                    break;
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string primero = comboBox2.SelectedItem.ToString();
            switch (primero)
            {
                case "Arroz con verduras":
                    //Esto es para que coloque la imagen segun la opcion que marquemos
                    pictureBox2.Image = Properties.Resources.arroz;
                    
                    
                    break;
                case "Potaje":
                    pictureBox2.Image = Properties.Resources.potje;
                    
                    
                    break;
                case "Espaguetis":
                    pictureBox2.Image = Properties.Resources.espagueti;
                    
                    
                    break;
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            string segundo = comboBox3.SelectedItem.ToString();
            switch (segundo)
            {
                case "Merluza con salsa":
                    //Esto es para que coloque la imagen segun la opcion que marquemos
                    pictureBox3.Image = Properties.Resources.merluz;
                    
                    
                    break;
                case "Calamares":
                    pictureBox3.Image = Properties.Resources.calamares;
                    
                   
                    break;
                case "Ternera con patatas":
                    pictureBox3.Image = Properties.Resources.ternera;
                    
                   
                    break;
            }
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            string Postre = comboBox4.SelectedItem.ToString();
            switch (Postre)
            {
                case "Trata de Frutos rojos":
                    //Esto es para que coloque la imagen segun la opcion que marquemos
                    pictureBox4.Image = Properties.Resources.tarata_rojos;
                    
                    
                    break;
                case "Tarta de chocolate":
                    pictureBox4.Image = Properties.Resources.tarta_cho;
                    
                    
                    break;
                case "Flan":
                    pictureBox4.Image = Properties.Resources._650_1200;
                    
                    
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {//esto es pare que si no pones nada te diga que selecciones cosas 
            if (comboBox1.SelectedIndex == -1) MessageBox.Show("tienes nada seleccionado");
            else
            {//para sumar cada cosa con su precio

                if (comboBox1.SelectedIndex == 0) precio += 4;
                if (comboBox1.SelectedIndex == 1) precio += 3;
                if (comboBox1.SelectedIndex == 2) precio += 4;


                if (comboBox2.SelectedIndex == 0) precio += 4;
                if (comboBox2.SelectedIndex == 1) precio += 4;
                if (comboBox2.SelectedIndex == 2) precio += 3;



                if (comboBox3.SelectedIndex == 0) precio += 5;
                if (comboBox3.SelectedIndex == 1) precio += 6;
                if (comboBox3.SelectedIndex == 2) precio += 6;


                if (comboBox4.SelectedIndex == 0) precio += 4;
                if (comboBox4.SelectedIndex == 1) precio += 4;
                if (comboBox4.SelectedIndex == 2) precio += 3;

                
                button1.Text = precio.ToString();
                
            }
            
        }
       
    }
}
