package com.company;

import java.util.Scanner;

public class Main {
//Ponemos scaner para poder leer
static Scanner sc = new Scanner(System.in);

//la funcion
static public String funcion1(String cifra) {
        int n, cifras;
        char car;

        System.out.print("Introduce un número entero: ");
        n = sc.nextInt();
        cifras = 0;    //esta variable es el contador de cifras
        while (n != 0) {             //mientras a n le queden cifras
        n = n / 10;         //le quitamos el último dígito
        cifras++;          //sumamos 1 al contador de cifras

        }
        return "El número tiene " + cifras + " cifras";


        }

static public int funcion2(String sPalabra) {
        int contador = 0;
        System.out.println("Dime una palabra");
        sPalabra = sc.next();
        //le decimos que lea la palabra cada palabra que lea que sea vocal que valla sumando 1 al marcador
        for (int x = 0; x < sPalabra.length(); x++) {
        if ((sPalabra.charAt(x) == 'a') || (sPalabra.charAt(x) == 'e') || (sPalabra.charAt(x) == 'i') || (sPalabra.charAt(x) == 'o') || (sPalabra.charAt(x) == 'u')) {
        contador++;
        }
        }
        return contador;
        }


static public double funcion3(String Circulo) {
        Double radio, area;

        System.out.println("Dime el radio");
        radio = sc.nextDouble();
        //hacemos la operacon de pi
        area = Math.PI * radio;

        return area;

        }

static public double funcion4(String Division) {
        // Crea varias variables de tipo entero
        int dia, mes, anio, suma, digito1, digito2, digito3, digito4, sumafinal;
        //Crea un objeto llamado "entrada" haciendo uso de la utilidad Scanner asociado al dispositivo de entrada.
        Scanner entrada = new Scanner(System.in);
        //Hace aparecer un texto en pantalla y además permite la introducción de un dato, por eso se usa "printf" ya que utiliza una cadena de formato
        System.out.printf("Introduzca su día de nacimiento: ");
        //Define la variable anteriormente creada "dia" con el dato introducido que ha sido leido por el objeto creado anteriormente usando la clase Scanner "entrada" de un número entero (por eso "entrada.nextInt")
        dia = entrada.nextInt();
        //Hace aparecer un texto en pantalla y además permite la introducción de un dato, por eso se usa "printf" ya que utiliza una cadena de formato
        System.out.printf("Introduzca su mes de nacimiento: ");
        //Define la variable anteriormente creada "mes" con el dato introducido que ha sido leido por el objeto creado anteriormente usando la clase Scanner "entrada" de un número entero (por eso "entrada.nextInt")
        mes = entrada.nextInt();
        //Hace aparecer un texto en pantalla y además permite la introducción de un dato, por eso se usa "printf" ya que utiliza una cadena de formato
        System.out.printf("Introduzca su año de nacimiento: ");
        //Define la variable anteriormente creada "anio" con el dato introducido que ha sido leido por el objeto creado anteriormente usando la clase Scanner "entrada" de un número entero (por eso "entrada.nextInt")
        anio = entrada.nextInt();
        //Define la variable anteriormente creada "suma" con la suma de todos los datos introducidos anteriormente
        suma = dia + mes + anio;

        //Define la variable anteriormente creada "digito1" con un calculo de la suma para poder obtener el primer digito
        digito1 = suma / 1000;
        //Define la variable anteriormente creada "digito2" con un calculo de la suma para poder obtener el segundo digito
        digito2 = suma / 100 % 10;
        //Define la variable anteriormente creada "digito3" con un calculo de la suma para poder obtener el tercer digito
        digito3 = suma / 10 % 10;
        //Define la variable anteriormente creada "digito4" con un calculo de la suma para poder obtener el cuarto digito
        digito4 = suma % 10;
        //Define la variable anteriormente creada "sumafinal" sumando todos los digitos.
        sumafinal = digito1 + digito2 + digito3 + digito4;
        // Hace aparecer en pantalla un texto que incluye el valor de la variable "sumafinal". Se usa printf porque es una cadena de formato.
//saca el resultado
        return +sumafinal;
        }


static public String funcion5(String Salir) {
        //ponemos por pantalla salir
        return "Has decidido salir";


        }


public static void main(String[] args) {
        //Hacemos el menu



            int respuesta;
            //Hacemos el while para que se repita hasta que salga 0
    do {
        System.out.println("1-Cantidad de cifras");
        System.out.println("2-Contar Vocales");
        System.out.println("3-Area del circulo");
        System.out.println("4-division");
        System.out.println("0-Salir");
        respuesta = sc.nextInt();
        //hacemos un switch para las diferentes opciones
        switch (respuesta) {
            case 1:
                String cifras = "";
                System.out.println(funcion1(cifras));
                break;
            case 2:
                String vocales = "";

                System.out.println(funcion2(vocales));
                break;
            case 3:
                String circulo = "";
                System.out.println(funcion3(circulo));
                break;
            case 4:
                String Division = "";
                System.out.println(funcion4(Division));
                break;
            case 0:
                String salir = "";
                System.out.println(funcion5(salir));
                break;
        }
    } while (respuesta !=0 ) ;









        }
        }
