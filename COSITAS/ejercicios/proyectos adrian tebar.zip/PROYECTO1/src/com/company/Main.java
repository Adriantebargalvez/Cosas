package com.company;

import java.util.Random;
import java.util.Scanner;

public class Main {
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        // write your code here
            int suma, tirada=0;

        do{
            Random aleatorio = new Random();
            int dado = aleatorio.nextInt(6) + 1;
            int dado2 = aleatorio.nextInt(6) + 1;
            suma = dado + dado2;
            System.out.println(suma);
            if (suma == 7 || suma == 11) {
                System.out.println("Has ganado");
            } else {
                if (suma == 2 || suma == 3 || suma == 12) {
                    System.out.println("Has perdido");
                }else {
                    if (suma == 4 || suma == 5 || suma == 6 || suma == 8 || suma == 9 || suma == 10) ;
                    tirada = suma;
                    System.out.println("Vuelve a tirar");
                }
            }

            }while (suma == tirada) ;
        if (suma!=7&&suma!=11)
        System.out.println("has ganado");


        }
    }
