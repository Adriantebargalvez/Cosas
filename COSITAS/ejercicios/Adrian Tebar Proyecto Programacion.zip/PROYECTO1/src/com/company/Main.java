package com.company;

import java.util.Random;
import java.util.Scanner;

public class Main {
    //ponemos el scanner estatic para que lo podamos usar en todo el programa
    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        // write your code here
        //decimos las variables
            int suma, tirada=0;
        //lo metemos todo dentro de un while para que se repita siempre hasta que se de la condicion
        do{
            //numero aleatorio
            Random aleatorio = new Random();
            int dado = aleatorio.nextInt(6) + 1;
            int dado2 = aleatorio.nextInt(6) + 1;
            suma = dado + dado2;
            System.out.println(suma);
            //hacemos un if que si sale un 7 o un 11 ganas
            if (suma == 7 || suma == 11) {
                System.out.println("Has ganado");
            } else {
                //si sale un 2,3,12 has perdido
                if (suma == 2 || suma == 3 || suma == 12) {
                    System.out.println("Has perdido");
                }else {
                    //si sale un 4,5,6,8,9,10 se vuelve a tirar
                    if (suma == 4 || suma == 5 || suma == 6 || suma == 8 || suma == 9 || suma == 10) ;
                    tirada = suma;
                    System.out.println("Vuelve a tirar");
                }
            }
//fin de la repeticion
            }while (suma == tirada) ;
        //si vuelve a tirar y sale un 7 o 11 ganas
        if (suma!=7&&suma!=11)
        System.out.println("has ganado");


        }
    }
