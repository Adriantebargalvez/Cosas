﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyecto01
{
    public partial class Form1 : Form

    {
        //la variable pantalla es donde se almacenara las operaciones 
        String pantalla = "";
       
       
        public Form1()
        {
            InitializeComponent();
            //es para que este la pantalla vacia
            lpantalla.Text = "";
        }
        public void addboton (String simbolo1)
        {
            // añades a cada boton para que cuando lo pulses salga ese simbolo
            pantalla+=simbolo1;
            lpantalla.Text = pantalla;
           
        }
    private void button1_Click(object sender, EventArgs e)
        {
            //al darle a este voton aparecira un 1
            addboton("1");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void igual_Click(object sender, EventArgs e)
        {


//hacemos un if para que muestre no se puede operar al hacer las siguientes operaciones
//mostrara no se puede operar cuando cualquier numero lo divida entre 0
            if (pantalla.Contains("/0") || pantalla.Length == 0)
            {
                lpantalla.Text = "No se puede operar";

            }
            //mostrara no se puede operar cuando esten dos simbolos juntos
            else if (new[] { "++", "+-", "+*", "+/", "--", "-+", "-*", "-/", "*+", "*-", "*/", "**", "//", "/+", "/-", "/*" }.Any(c => pantalla.Contains(c)))
            {
                lpantalla.Text = "No se puede operar";
            }
            //si al final de la operacion hay un simblo dara mostrara por pantalla no se puede operar
            else if (pantalla[pantalla.Length - 1] == '+' || pantalla[pantalla.Length - 1] == '-' ||
                pantalla[pantalla.Length - 1] == '*' || pantalla[pantalla.Length - 1] == '/'){

                lpantalla.Text = "No se puede operar";
            }
            else
            {
                var resultado = new DataTable().Compute(pantalla, null);
                lpantalla.Text = Convert.ToString(Math.Round(Convert.ToDecimal(resultado), 2));
            }
            pantalla = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button0_Click(object sender, EventArgs e)
        {
            addboton ("0");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            addboton("2");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            addboton("3");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            addboton("4");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            addboton("5");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            addboton("6");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            addboton("7");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            addboton("8");
        }

        private void button9_Click(object sender, EventArgs e)
        {
            addboton("9");
        }

        private void borrar_Click(object sender, EventArgs e)
        {
            pantalla = "";
            lpantalla.Text = pantalla;
        }

        private void resta_Click(object sender, EventArgs e)
        {
            addboton("-");
        }

        private void suma_Click(object sender, EventArgs e)
        {
            addboton("+");
        }

        private void divi_Click(object sender, EventArgs e)
        {
            addboton("/");
        }

        private void multi_Click(object sender, EventArgs e)
        {
            addboton("*");
        }
    }
}
